<?php
session_start(); // Start the session

// Retrieve customer_id from session
$customer_id = isset($_SESSION['customer_id']) ? (int)$_SESSION['customer_id'] : 0;

// Check if the customer is logged in
if (empty($customer_id)) {
    header("Location: login.php");
    exit();
}

// Include database connection
include('connection.php');

// Fetch order history for the logged-in customer where active = 0
$sql = "SELECT oc.order_id, oc.order_token, oc.total_price, oc.order_date, oc.discount_price
        FROM order_customer oc
        WHERE oc.customer_id = ? AND oc.active = 0 
        ORDER BY oc.order_date DESC";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param('i', $customer_id);

if (!$stmt->execute()) {
    die('Execute failed: ' . htmlspecialchars($stmt->error));
}

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <style>
       body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: #f9f9f9;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.header {
    background: #4CAF50;
    color: #fff;
    padding: 20px 0;
    width: 100%;
    text-align: center;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    display: flex;
    justify-content: center;
    align-items: center;
}

.header h1 {
    margin: 0;
    font-size: 28px;
    flex: 1;
}

.header .back-button {
    position: absolute;
    top: 20px;
    right: 20px;
    padding: 8px 16px;
    background: #fff;
    color: #4CAF50;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
}

.header .back-button:hover {
    background: #f0f0f0;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 80px auto 30px auto;
    padding: 0 20px;
}

.order-card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 20px;
    overflow: hidden;
    width: 100%;
    max-width: 800px;
    margin: 10px auto;
    text-align: center;
    position: relative;
}

.order-card h2 {
    margin: 0 0 10px;
    font-size: 24px;
    color: #333;
    border-bottom: 2px solid #4CAF50;
    padding-bottom: 10px;
}

.order-card p {
    font-size: 16px;
    margin: 10px 0;
}

.order-card p span {
    font-weight: bold;
    color: #4CAF50;
}

.order-details {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: center;
}

.order-details .product {
    flex: 1 1 calc(33.333% - 20px);
    box-sizing: border-box;
    text-align: center;
    margin-bottom: 20px;
}

.order-details img {
    border-radius: 4px;
    width: 150px;
    height: 150px;
    object-fit: cover;
    display: block;
    margin: 0 auto;
}

.product p {
    margin-top: 10px;
    font-size: 14px;
}

.rating-button {
    padding: 8px 16px;
    background: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
    margin-top: 10px;
}

.rating-button:hover {
    background: #45a049;
}

    </style>
</head>
<body>
    <header class="header">
        <h1>Order History</h1>
        <button class="back-button" onclick="window.location.href='index.php';">Back to Home</button>
    </header>
    <div class="container">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($order = $result->fetch_assoc()): ?>
                <div class="order-card">
                    <h2>Order #<?php echo htmlspecialchars($order['order_id']); ?></h2>
                    <p><span>Order Token:</span> <?php echo htmlspecialchars($order['order_token']); ?></p>
                    <p><span>Total Price:</span> $<?php echo htmlspecialchars(number_format($order['total_price'], 2)); ?></p>
                    <p><span>Discount:</span> $<?php echo htmlspecialchars(number_format($order['discount_price'], 2)); ?></p>
                    <p><span>Order Date:</span> <?php echo htmlspecialchars(date('F j, Y', strtotime($order['order_date']))); ?></p>
                    <div class="order-details">
                        <?php 
                        // Retrieve images and product names for this order
                        $productSql = "SELECT p.product_name, pp.photo_path, p.product_id 
                                        FROM product_photo pp 
                                        JOIN customer_product cp ON pp.product_id = cp.product_id 
                                        JOIN product p ON pp.product_id = p.product_id 
                                        WHERE cp.order_id = ? 
                                        LIMIT 3"; // Limit to 3 images
                        $productStmt = $conn->prepare($productSql);
                        $productStmt->bind_param('i', $order['order_id']);
                        $productStmt->execute();
                        $productResult = $productStmt->get_result();
                        while ($photo = $productResult->fetch_assoc()): ?>
                            <div class="product">
                                <img src="<?php echo htmlspecialchars($photo['photo_path']); ?>" alt="Product Image">
                                <p><?php echo htmlspecialchars($photo['product_name']); ?></p>
                                <button class="rating-button" onclick="window.location.href='product_rating.php?customer_id=<?php echo htmlspecialchars($customer_id); ?>&product_id=<?php echo htmlspecialchars($photo['product_id']); ?>&order_id=<?php echo htmlspecialchars($order['order_id']); ?>'">Rate</button>
                            </div>
                        <?php endwhile; ?>
                        <?php $productStmt->close(); ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No orders found.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>

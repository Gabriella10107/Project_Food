<?php
$host = "127.0.0.1";
$user = "root";
$pass = ""; // Update this with the correct password
$database = "food"; // Change this to your actual database name
$port = 3307; // Specify the port number

// Create a MySQLi connection
$conn = new mysqli($host, $user, $pass, $database, $port);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>

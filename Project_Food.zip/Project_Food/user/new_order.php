<?php
session_start(); // Start the session

// Retrieve customer_id from session
$customer_id = isset($_SESSION['customer_id']) ? (int)$_SESSION['customer_id'] : 0;

// Check if the customer is logged in
if (empty($customer_id)) {
    header("Location: login.php");
    exit();
}

// Include database connection
include('connection.php');

// Fetch order history for the logged-in customer where active = 1
$sql = "SELECT oc.order_id, oc.order_token, oc.total_price, oc.order_date, oc.discount_price 
        FROM order_customer oc
        WHERE oc.customer_id = ? AND oc.active = 1 
        ORDER BY oc.order_date DESC";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param('i', $customer_id);

if (!$stmt->execute()) {
    die('Execute failed: ' . htmlspecialchars($stmt->error));
}

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <style>
   body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: #f9f9f9;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.header {
    background: #4CAF50;
    color: #fff;
    padding: 20px 0;
    width: 100%;
    text-align: center;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    border-bottom: 4px solid #333; /* Adds a border below the header */
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 80px auto 30px auto;
    padding: 0 20px;
}

.order-card {
    background: #fff;
    border-radius: 8px;
    border: 2px solid #4CAF50; /* Adds a green border to order cards */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 20px;
    overflow: hidden;
    width: 100%;
    max-width: 800px;
    margin: 10px auto;
}

.order-card h2 {
    margin: 0 0 10px;
    font-size: 24px;
    color: #333;
    border-bottom: 2px solid #4CAF50;
    padding-bottom: 10px;
}

.order-details {
    border-top: 1px solid #eee;
    padding-top: 10px;
    margin-top: 10px;
}

.order-details p {
    font-size: 16px;
    margin: 10px 0;
}

.order-details p span {
    font-weight: bold;
    color: #4CAF50;
}

.products-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: space-between;
}

.product-card {
    background: #fff;
    border-radius: 8px;
    border: 2px solid #4CAF50; /* Adds a green border to product cards */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 10px;
    width: calc(33.333% - 10px); /* Three items per row with space */
    box-sizing: border-box;
    text-align: center;
    margin-bottom: 10px; /* Adds space below each product card */
}

.product-card img {
    border-radius: 4px;
    width: 100%;
    height: auto;
}

.button-container {
    
    position: fixed;
    bottom: 390px; /* Adjusted from 600px to 30px */
   right:0;
   margin-bottom:220px ;
    z-index: 1000;
}

.button {
    padding: 12px 24px;
    background: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}

.button:hover {
    background: #45a049;
}


    </style>
</head>
<body>
    <div class="header">
        <h1>Your Current Orders</h1>
    </div>
    <div class="container">
        <?php
        $current_date = '';
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $order_date = date('F j, Y', strtotime($row['order_date']));
                if ($order_date !== $current_date) {
                    if ($current_date !== '') {
                        echo '</div>'; // Close previous date block
                    }
                    echo '<div class="order-card">';
                    echo '<h2>' . $order_date . '</h2>'; // Display the date
                    $current_date = $order_date;
                }
                echo '<div class="order-details">';
                echo '<p><span>Order Token:</span> ' . htmlspecialchars($row['order_token']) . '</p>';
                echo '<p><span>Total Price:</span> $' . number_format((float)$row['total_price'], 2, '.', '') . '</p>';
                echo '<p><span>Discount Price:</span> $' . number_format((float)$row['discount_price'], 2, '.', '') . '</p>';
                echo '<p><span>Order Date:</span> ' . date('F j, Y, g:i a', strtotime($row['order_date'])) . '</p>';
                
                // Fetch and display product details for the current order
                $order_id = $row['order_id'];
                $product_sql = "SELECT p.product_name, pp.photo_path, cp.quantity, 
                                       p.product_price, 
                                       COALESCE(promo.promotion_percent, 0) AS promotion_percent
                                FROM customer_product cp 
                                JOIN product p ON cp.product_id = p.product_id 
                                JOIN product_photo pp ON cp.product_id = pp.product_id
                                LEFT JOIN promotion promo ON p.product_id = promo.product_id
                                WHERE cp.order_id = ? AND cp.active_product = 1";
                $product_stmt = $conn->prepare($product_sql);

                if ($product_stmt === false) {
                    die('Prepare failed: ' . htmlspecialchars($conn->error));
                }

                $product_stmt->bind_param('i', $order_id);

                if (!$product_stmt->execute()) {
                    die('Execute failed: ' . htmlspecialchars($product_stmt->error));
                }

                $product_result = $product_stmt->get_result();

                if ($product_result->num_rows > 0) {
                    echo '<div class="products-grid">';
                    while ($product = $product_result->fetch_assoc()) {
                        // Get promotion percent and calculate the price
                        $promotionPercent = (float)$product['promotion_percent'];
                        $originalPrice = (float)$product['product_price'];
                        if ($promotionPercent > 0) {
                            $discountedPrice = $originalPrice - ($originalPrice * ($promotionPercent / 100));
                            $priceDisplay = "<del>$" . number_format($originalPrice, 2) . "</del> $" . number_format($discountedPrice, 2);
                        } else {
                            $priceDisplay = "$" . number_format($originalPrice, 2);
                        }

                        echo '<div class="product-card">';
                        echo '<p><span>Product Name:</span> ' . htmlspecialchars($product['product_name']) . '</p>';
                        echo '<p><span>Quantity:</span> ' . (int)$product['quantity'] . '</p>';
                        echo '<p><span>Price:</span> ' . $priceDisplay . '</p>';
                        echo '<img src="' . htmlspecialchars($product['photo_path']) . '" alt="' . htmlspecialchars($product['product_name']) . '">';
                        echo '</div>';
                    }
                    echo '</div>'; // Close products-grid div
                } else {
                    echo '<p>No products found for this order.</p>';
                }
                echo '</div>'; // Close order-details div
            }
            echo '</div>'; // Close last date block
        } else {
            echo '<p>No orders found.</p>';
        }

        $stmt->close();
        $conn->close();
        ?>
    </div>
    <div class="button-container">
        <a href="index.php" class="button">Back to Home</a>
    </div>
</body>
</html>

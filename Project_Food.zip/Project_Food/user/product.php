<?php
session_start(); // Start the session

// Check if the user is logged in
$is_logged_in = isset($_SESSION['customer_email']) && isset($_SESSION['customer_password']);
?>
<!-- CSS for the star rating -->



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Primary meta tags -->
  <title>Grilli - Amazing & Delicious Food</title>
  <meta name="title" content="Grilli - Amazing & Delicious Food">
  <meta name="description" content="This is a Restaurant html template made by codewithsadee">

  <!-- Favicon -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- Google font link -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Forum&display=swap" rel="stylesheet">

  <!-- Custom CSS link -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- Preload images -->
  <link rel="preload" as="image" href="./assets/images/hero-slider-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-slider-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-slider-3.jpg">
</head>

<style type="text/css">
    .rating {
      display: flex;
      justify-content: center;
    }

    .star {
      font-size: 20px;
      color: #f39c12; /* Gold color for stars */
    }

    .star:last-child {
      margin-right: 0;
    }

    .star.filled {
      color: #f39c12; /* Gold color for filled stars */
    }

    .btn-secondary {
      background-color: #b89a6f; /* Light wood color */
      color: #fff;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
      display: inline-flex;
      align-items: center;
    }

    .btn-secondary:hover {
      background-color: #8f6f4a; /* Slightly darker wood color */
    }

    .product-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 20px;
      padding: 20px;
    }

    .product-card {
      background: rgba(255, 255, 255, 0.8); /* Semi-transparent background color */
      border-radius: 12px; /* Rounded corners */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Soft shadow */
      overflow: hidden;
      width: 100%;
      max-width: 300px; /* Set a maximum width */
      margin: 20px;
      transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth transition */
      text-align: center;
    }

    .product-card:hover {
      transform: translateY(-10px); /* Lift up on hover */
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); /* Deep shadow on hover */
    }

    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-bottom: 2px solid #eee; /* Add a border below the image */
    }

    .product-card h2 {
      font-size: 1.5em;
      margin: 15px 0 5px;
      color: #333; /* Darker text color */
    }

    .product-card p {
      color: #777; /* Lighter text color for description */
      margin: 0 0 15px;
      padding: 0 15px; /* Add padding for better text alignment */
    }

    .product-card .price {
      font-size: 1.2em;
      color: #e67e22; /* Use a distinctive color for the price */
      margin-bottom: 10px;
    }

    .product-card .rating {
      margin: 10px 0;
    }

    body {
      overflow: auto; /* Ensure scrolling is enabled */
    }

    .fixed-element {
      position: fixed; /* Make sure this is necessary */
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      overflow: auto; /* Ensure it allows scrolling if necessary */
    }

    .span {
      color: white;
    }

    .navbar-list {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
    }

    .navbar-item {
      position: relative;
    }

    .navbar-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: #333;
      padding: 0.5rem 1rem;
      font-size: 1rem;
      font-weight: 500;
      transition: color 0.3s ease, background-color 0.3s ease;
    }

    .navbar-link:hover,
    .navbar-link.active {
      color: #007bff;
    }

    .dropdown-toggle::after {
      content: "\25BC"; /* Downward arrow */
      margin-left: 0.5rem;
    }

    .dropdown-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      z-index: 1000;
      min-width: 160px;
      padding: 0.5rem 0;
      margin: 0;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 0.25rem;
      box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }

    .dropdown:hover .dropdown-menu {
      display: block;
    }

    .dropdown-menu li {
      list-style: none;
    }

    .dropdown-menu a {
      display: block;
      padding: 0.5rem 1rem;
      color: #333;
      text-decoration: none;
      white-space: nowrap;
      transition: background-color 0.3s ease;
    }

    .dropdown-menu a:hover {
      background-color: #f8f9fa;
    }

    .separator {
      display: inline-block;
      width: 1px;
      height: 1.25rem;
      margin: 0 0.5rem;
      background-color: #dee2e6;
    }

    .btn-secondary {
      padding-left: 30px;
      padding-right: 30px;
    }
  </style>

<?php


// Retrieve customer_id from URL or session
$customer_id = isset($_GET['customer_id']) ? htmlspecialchars($_GET['customer_id']) : (isset($_SESSION['customer_id']) ? $_SESSION['customer_id'] : null);

// Check if the customer is logged in
$is_logged_in = !empty($customer_id);

// Redirect to login page if no customer_id is found and the user is not logged in
if (!$is_logged_in) {
    // You might want to uncomment the following lines if you need to redirect
    // header("Location: login.php");
    // exit();
}
?>



<?php
// Database configuration
include('connection.php');

// Start session




    // Fetch customer email
    $sql = "SELECT customer_email FROM customer WHERE customer_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $customer_email = $row['customer_email'];
    } else {
        $customer_email = "";
    }

    $stmt->close();

?>

<body id="top">

 <!-- <div class="preload" data-preaload>
    <div class="circle"></div>
    <p class="text">Grilli</p>
  </div>
-->
  <div class="topbar">
    <div class="container">
      <address class="topbar-item">
        <div class="icon">
          <ion-icon name="location-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">Restaurant St, Delicious City, London 9578, UK</span>
      </address>

      <div class="separator"></div>

      <div class="topbar-item item-2">
        <div class="icon">
          <ion-icon name="time-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">Daily : 8.00 am to 10.00 pm</span>
      </div>

      <a href="tel:+11234567890" class="topbar-item link">
        <div class="icon">
          <ion-icon name="call-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">+1 123 456 7890</span>
      </a>

      <div class="separator"></div>

      <a href="mailto:booking@restaurant.com" class="topbar-item link">
        <div class="icon">
          <ion-icon name="mail-outline" aria-hidden="true"></ion-icon>
        </div>
         <p>: <?php echo htmlspecialchars($customer_email); ?></p>
      </a>

    </div>
  </div>

  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        <img src="./assets/images/logo.svg" width="160" height="50" alt="Grilli - Home">
      </a>

      <nav class="navbar" data-navbar>

        <button class="close-btn" aria-label="close menu" data-nav-toggler>
          <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
        </button>

        <a href="#" class="logo">
          <img src="./assets/images/logo.svg" width="160" height="50" alt="Grilli - Home">
        </a>
<ul class="navbar-list">
    <li class="navbar-item">
        <a href="index.php" class="navbar-link hover-underline active">
            <div class="separator"></div>
            <span class="span">Home</span>
        </a>
    </li>
    <li class="navbar-item">
        <a href="index.php#menu" class="navbar-link hover-underline">
            <div class="separator"></div>
            <span class="span">Menus</span>
        </a>
    </li>
    <li class="navbar-item">
        <a href="index.php#promotion" class="navbar-link hover-underline">
            <div class="separator"></div>
            <span class="span">Promotion</span>
        </a>
    </li>
    <li class="navbar-item">
        <a href="index.php#packages" class="navbar-link hover-underline">
            <div class="separator"></div>
            <span class="span">Packages</span>
        </a>
    </li>
   
    </li>

    <li class="navbar-item dropdown">
        <a href="#" class="navbar-link hover-underline dropdown-toggle">
            <div class="separator"></div>
            <span class="span">Orders</span>
        </a>
        <ul class="dropdown-menu">
            <li><a href="new_order.php?customer_id=<?php echo urlencode(htmlspecialchars($customer_id)); ?>">Order</a></li>
            <li><a href="order_history.php?customer_id=<?php echo urlencode(htmlspecialchars($customer_id)); ?>">History</a></li>
        </ul>
    </li>

    <li class="navbar-item">
        
    </li>
    <li class="navbar-item">
        
    </li>
    <li class="navbar-item">
        
    </li>
    <li class="navbar-item">
        
    </li>
    <li class="navbar-item">
        
    </li>

</ul>


        <div class="text-center">
          <p class="headline-1 navbar-title">Visit Us</p>
          <address class="body-4">
            Restaurant St, Delicious City, <br>
            London 9578, UK
          </address>
          <p class="body-4 navbar-text">Open: 9.30 am - 2.30pm</p>
          <a href="mailto:booking@grilli.com" class="body-4 sidebar-link">booking@grilli.com</a>
          <div class="separator"></div>
          <p class="contact-label">Booking Request</p>
          <a href="tel:+88123123456" class="body-1 contact-number hover-underline">
            +88-123-123456
          </a>
        </div>

      </nav>

  
    </div>
  </header>



    <!-- Rest of your page content -->



      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <span class="line line-1"></span>
        <span class="line line-2"></span>
        <span class="line line-3"></span>
      </button>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>


<?php
// Include database connection
include('connection.php');

// Initialize variables for error/success messages
$error_message = '';

// Get menu_id from query parameter if available
$menu_id = isset($_GET['menu_id']) ? (int)$_GET['menu_id'] : 0;

// Fetch unique products and their associated photos filtered by menu_id
$sql = "
    SELECT p.product_id, p.product_name, p.product_des, p.product_price, COALESCE(p.average_rating, 0) AS average_rating, 
           ph.photo_path, promo.promotion_percent
    FROM product p
    LEFT JOIN product_photo ph ON p.product_id = ph.product_id
    LEFT JOIN promotion promo ON p.product_id = promo.product_id
    WHERE p.menu_id = ?
    GROUP BY p.product_id
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $menu_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $error_message = "No products found for this menu.";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product List</title>
  <style>
    .product-section {
      margin-top: 200px;
    }

    .product-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px; /* Space between cards */
      justify-content: center; /* Center cards horizontally */
    }

    .product-card {
      background: rgba(255, 255, 255, 0.9); /* Semi-transparent background color */
      border-radius: 8px; /* Rounded corners */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
      overflow: hidden;
      width: 300px; /* Fixed width for cards */
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-card:hover {
      transform: translateY(-5px); /* Lift up on hover */
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2); /* Deep shadow on hover */
    }

    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .product-card h2 {
      font-size: 1.5em;
      margin: 15px 0 5px;
    }

    .product-card p {
      margin: 0 15px 15px;
      padding: 0 15px;
    }

    .price {
      font-size: 1.2em;
      color: #e67e22; /* Use a distinctive color for the price */
    }

    .price del {
      color: #999; /* Color for the original price */
      font-size: 1em;
      margin-right: 5px;
    }

    .rating {
      margin: 10px 0;
    }

    .star {
      font-size: 20px;
      color: #f39c12; /* Gold color for stars */
    }

    .star.filled {
      color: #f39c12; /* Gold color for filled stars */
    }

    .error-message {
      color: red;
      text-align: center;
      font-weight: bold;
    }
  </style>
</head>

<body>
  <!-- Product Section -->
  <section class="product-section">
    <div class="container">
      <?php if ($error_message): ?>
        <p class="error-message"><?php echo $error_message; ?></p>
      <?php else: ?>
        <div class="product-container">
          <?php while ($row = $result->fetch_assoc()): ?>
            <div class="product-card">
              <?php if ($row['photo_path']): ?>
                <img src="<?php echo htmlspecialchars($row['photo_path']); ?>" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
              <?php endif; ?>
              <h2><?php echo htmlspecialchars($row['product_name']); ?></h2>
              <p><?php echo htmlspecialchars($row['product_des']); ?></p>
              
              <!-- Price Calculation and Display -->
              <?php
                $originalPrice = (float)$row['product_price'];
                $promotionPercent = isset($row['promotion_percent']) ? (float)$row['promotion_percent'] : null;
                
                if ($promotionPercent !== null) {
                  // Calculate discounted price
                  $discountedPrice = $originalPrice - ($originalPrice * ($promotionPercent / 100));
                  echo "<p class='price'>
                        <del>$" . htmlspecialchars(number_format($originalPrice, 2)) . "</del> $" . htmlspecialchars(number_format($discountedPrice, 2)) . "
                        </p>";
                } else {
                  // Display normal price
                  echo "<p class='price'>$" . htmlspecialchars(number_format($originalPrice, 2)) . "</p>";
                }
              ?>
              
              <div class="rating">
                <?php 
                $rating = (float)$row['average_rating'];
                for ($i = 0; $i < 5; $i++) {
                  if ($i < $rating) {
                    echo '<span class="star filled">&#9733;</span>';
                  } else {
                    echo '<span class="star">&#9734;</span>';
                  }
                }
                ?>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer" style="margin-top: 200px;" >
    <div class="container">
      <p>&copy; 2024 Your Company Name. All rights reserved.</p>
    </div>
  </footer>

  <!-- Custom JS link -->
  <script src="./assets/js/main.js" defer></script>
</body>

</html>

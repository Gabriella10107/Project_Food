<?php
session_start(); // Start the session

// Retrieve customer_id from URL or session
$customer_id = isset($_GET['customer_id']) ? htmlspecialchars($_GET['customer_id']) : (isset($_SESSION['customer_id']) ? $_SESSION['customer_id'] : null);

// Check if the customer is logged in
$is_logged_in = !empty($customer_id);

if (!$is_logged_in) {
    header("Location: login.php");
    exit();
}

// Include your database connection file
include('connection.php');

// SQL query to create the cart table
$sql_create_cart_table = "
CREATE TABLE IF NOT EXISTS cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    total_price DECIMAL(10, 2) NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    FOREIGN KEY (product_id) REFERENCES product(product_id)
) ENGINE=InnoDB;
";

// Execute the query to create the table
if ($conn->query($sql_create_cart_table) === TRUE) {
    // Table created successfully
} else {
    echo "Error creating table 'cart': " . htmlspecialchars($conn->error);
}

// Initialize messages
$error_message = '';
$success_message = '';

// Retrieve parameters from the URL
$package_id = isset($_GET['package_id']) ? (int)$_GET['package_id'] : 0;
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

// Initialize product details
$product_name = '';
$product_price = 0.00;
$product_description = '';
$product_photo_path = '';

// Fetch product details including promotions
if ($product_id > 0) {
    $sql_fetch_product = "
        SELECT
            p.product_name,
            p.product_price,
            COALESCE(cr.average_rating, 0) AS average_rating,
            pp.photo_path,
            COALESCE(promo.promotion_percent, 0) AS promotion_percent
        FROM
            product p
        LEFT JOIN
            product_photo pp ON p.product_id = pp.product_id
        LEFT JOIN
            (SELECT product_id, AVG(rating) AS average_rating FROM customer_rating GROUP BY product_id) cr
            ON p.product_id = cr.product_id
        LEFT JOIN
            promotion promo ON p.product_id = promo.product_id
        WHERE
            p.product_id = ?
        GROUP BY
            p.product_id
    ";

    // Prepare and execute the query
    if ($stmt = $conn->prepare($sql_fetch_product)) {
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Calculate the final price based on the promotion
            $originalPrice = (float)$row['product_price'];
            $promotionPercent = (float)$row['promotion_percent'];

            if ($promotionPercent > 0) {
                // Calculate new price with promotion
                $product_price = $originalPrice - ($originalPrice * ($promotionPercent / 100));
                $price_display = "<div><del>$" . htmlspecialchars(number_format($originalPrice, 2)) . "</del></div>
                                  $" . htmlspecialchars(number_format($product_price, 2));
            } else {
                // No promotion, show normal price
                $product_price = $originalPrice;
                $price_display = "$" . htmlspecialchars(number_format($product_price, 2));
            }

            $product_name = htmlspecialchars($row['product_name']);
            $product_photo_path = htmlspecialchars($row['photo_path']);
        } else {
            $error_message = 'Product not found.';
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . htmlspecialchars($conn->error);
    }
} else {
    $error_message = "Invalid product ID.";
}

// Process the order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    $total_price = isset($_POST['product_price']) ? (float)$_POST['product_price'] * $quantity : 0;

    if ($product_id > 0 && $quantity > 0) {
        // Check if the product already exists in the cart
        $sql_check_cart = "SELECT cart_id, quantity, total_price FROM cart WHERE customer_id = ? AND product_id = ?";
        
        if ($stmt_check = $conn->prepare($sql_check_cart)) {
            $stmt_check->bind_param("ii", $customer_id, $product_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                // Product exists, update the quantity and total price
                $row = $result_check->fetch_assoc();
                $new_quantity = $row['quantity'] + $quantity;
                $new_total_price = $row['total_price'] + $total_price;

                $sql_update_cart = "UPDATE cart SET quantity = ?, total_price = ? WHERE cart_id = ?";
                
                if ($stmt_update = $conn->prepare($sql_update_cart)) {
                    $stmt_update->bind_param("idi", $new_quantity, $new_total_price, $row['cart_id']);
                    
                    if ($stmt_update->execute()) {
                        $success_message = 'Cart updated successfully.';
                    } else {
                        $error_message = 'Error updating cart: ' . htmlspecialchars($stmt_update->error);
                    }

                    $stmt_update->close();
                } else {
                    $error_message = 'Error preparing update statement: ' . htmlspecialchars($conn->error);
                }
            } else {
                // Product does not exist, insert a new row
                $sql_insert_cart = "INSERT INTO cart (customer_id, product_id, quantity, total_price)
                                    VALUES (?, ?, ?, ?)";
                
                if ($stmt_insert = $conn->prepare($sql_insert_cart)) {
                    $stmt_insert->bind_param("iiid", $customer_id, $product_id, $quantity, $total_price);
                    
                    if ($stmt_insert->execute()) {
                        $success_message = 'Added to cart successfully.';
                    } else {
                        $error_message = 'Error adding to cart: ' . htmlspecialchars($stmt_insert->error);
                    }

                    $stmt_insert->close();
                } else {
                    $error_message = 'Error preparing insert statement: ' . htmlspecialchars($conn->error);
                }
            }

            $stmt_check->close();
        } else {
            $error_message = 'Error preparing check statement: ' . htmlspecialchars($conn->error);
        }
    } else {
        $error_message = 'Invalid product ID or quantity.';
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order - <?php echo htmlspecialchars($product_name); ?></title>
    <link rel="stylesheet" href="path/to/your/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .product-card {
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            background-color: #f9f9f9;
            margin-bottom: 20px;
        }

        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .product-card h1 {
            font-size: 24px;
            color: #333;
            margin: 10px 0;
        }

        .price {
            font-size: 1.5em;
            color: #e74c3c;
            margin: 10px 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .quantity-controls {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .quantity-controls button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .quantity-controls button:hover {
            background-color: #0056b3;
        }

        .quantity-controls input {
            width: 60px;
            text-align: center;
            margin: 0 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn-container {
            display: flex;
            justify-content: space-between;
        }

        .btn {
            display: inline-block;
            padding: 12px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #218838;
        }

        .error, .success {
            color: #dc3545;
            font-size: 14px;
            text-align: center;
            margin: 10px 0;
        }

        .success {
            color: #28a745;
        }

        .total-price {
            font-size: 18px;
            color: #333;
            text-align: center;
            margin-top: 10px;
        }
    </style>
    <script>
        function calculateTotal() {
            var price = parseFloat(document.getElementById('product_price').value);
            var quantity = parseInt(document.getElementById('quantity').value);
            var total = price * quantity;
            document.getElementById('total_price').innerText = "$" + total.toFixed(2);
        }

        function adjustQuantity(change) {
            var quantityField = document.getElementById('quantity');
            var quantity = parseInt(quantityField.value) || 1;
            quantity = Math.max(quantity + change, 1); // Ensure quantity is at least 1
            quantityField.value = quantity;
            calculateTotal();
        }

        document.addEventListener('DOMContentLoaded', function() {
            calculateTotal(); // Initial calculation
        });
    </script>
</head>
<body>
    <header>
       
    </header>

    <main>
        <div class="container">
            <?php if ($success_message): ?>
                <div class="success"><?php echo $success_message; ?></div>
            <?php elseif ($error_message): ?>
                <div class="error"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <?php if ($product_id > 0 && !$error_message): ?>
                <div class="product-card">
                    <img src="<?php echo htmlspecialchars($product_photo_path); ?>" alt="<?php echo htmlspecialchars($product_name); ?>">
                    <h1><?php echo $product_name; ?></h1>
                    <div class="price" id="price_display"><?php echo $price_display; ?></div>
                    <p><?php echo $product_description; ?></p>

                    <form action="" method="post" oninput="calculateTotal()">
                        <input type="hidden" id="product_price" name="product_price" value="<?php echo htmlspecialchars($product_price); ?>">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">
                        <input type="hidden" name="customer_id" value="<?php echo htmlspecialchars($customer_id); ?>">

                        <div class="form-group">
                            <label for="quantity">Quantity:</label>
                            <div class="quantity-controls">
                                <button type="button" onclick="adjustQuantity(-1)">-</button>
                                <input type="number" id="quantity" name="quantity" value="1" min="1">
                                <button type="button" onclick="adjustQuantity(1)">+</button>
                            </div>
                        </div>

                        <div class="total-price" id="total_price"></div>

                        <div class="btn-container">
                            <a href="package_product.php?package_id=<?php echo $package_id; ?>&customer_id=<?php echo $customer_id; ?>" class="btn">Back to Product</a>
                            <button type="submit" class="btn">Add to Cart</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <!-- Your footer content here -->
    </footer>
</body>
</html>

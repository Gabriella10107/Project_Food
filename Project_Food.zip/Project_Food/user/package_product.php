<?php
session_start(); // Start the session

// Retrieve customer_id from URL or session
$customer_id = isset($_GET['customer_id']) ? htmlspecialchars($_GET['customer_id']) : (isset($_SESSION['customer_id']) ? $_SESSION['customer_id'] : null);

// Check if the customer is logged in
$is_logged_in = !empty($customer_id);

// Redirect to login page if no customer_id is found and the user is not logged in
if (!$is_logged_in) {
    // You might want to uncomment the following lines if you need to redirect
    // header("Location: login.php");
    // exit();
}
?>



<?php
// Database configuration
include('connection.php');

// Start session




    // Fetch customer email
    $sql = "SELECT customer_email FROM customer WHERE customer_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $customer_email = $row['customer_email'];
    } else {
        $customer_email = "";
    }

    $stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Grilli - Amazing & Delicious Food</title>
  <meta name="title" content="Grilli - Amazing & Delicious Food">
  <meta name="description" content="This is a Restaurant HTML template made by codewithsadee">
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Forum&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="preload" as="image" href="./assets/images/hero-slider-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-slider-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-slider-3.jpg">
</head>
<style type="text/css">
  /* General Navbar Styling */
/* Navbar List */
body {
    overflow: auto; /* Ensure scrolling is enabled */
}

.fixed-element {
    position: fixed; /* Make sure this is necessary */
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: auto; /* Ensure it allows scrolling if necessary */
}

.span {
    color:white;
}


.navbar-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
}

/* Navbar Item */
.navbar-item {
    position: relative;
}

/* Navbar Link */
.navbar-link {
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #333;
    padding: 0.5rem 1rem;
    font-size: 1rem;
    font-weight: 500;
    transition: color 0.3s ease, background-color 0.3s ease;
}

/* Hover State */
.navbar-link:hover,
.navbar-link.active {
    color: #007bff;
}

/* Dropdown Toggle */
.dropdown-toggle::after {
    content: "\25BC"; /* Downward arrow */
    margin-left: 0.5rem;
}

/* Dropdown Menu */
.dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    min-width: 160px;
    padding: 0.5rem 0;
    margin: 0;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 0.25rem;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

/* Show Dropdown Menu */
.dropdown:hover .dropdown-menu {
    display: block;
}

/* Dropdown Menu Item */
.dropdown-menu li {
    list-style: none;
}

.dropdown-menu a {
    display: block;
    padding: 0.5rem 1rem;
    color: #333;
    text-decoration: none;
    white-space: nowrap;
    transition: background-color 0.3s ease;
}

.dropdown-menu a:hover {
    background-color: #f8f9fa;
}

/* Separator Style */
.separator {
    display: inline-block;
    width: 1px;
    height: 1.25rem;
    margin: 0 0.5rem;
    background-color: #dee2e6;
}

</style>
<body id="top">

 <!-- <div class="preload" data-preaload>
    <div class="circle"></div>
    <p class="text">Grilli</p>
  </div>
-->
  <div class="topbar">
    <div class="container">
      <address class="topbar-item">
        <div class="icon">
          <ion-icon name="location-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">Restaurant St, Delicious City, London 9578, UK</span>
      </address>

      <div class="separator"></div>

      <div class="topbar-item item-2">
        <div class="icon">
          <ion-icon name="time-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">Daily : 8.00 am to 10.00 pm</span>
      </div>

      <a href="tel:+11234567890" class="topbar-item link">
        <div class="icon">
          <ion-icon name="call-outline" aria-hidden="true"></ion-icon>
        </div>
        <span class="span">+1 123 456 7890</span>
      </a>

      <div class="separator"></div>

      <a href="mailto:booking@restaurant.com" class="topbar-item link">
        <div class="icon">
          <ion-icon name="mail-outline" aria-hidden="true"></ion-icon>
        </div>
         <p>: <?php echo htmlspecialchars($customer_email); ?></p>
      </a>

    </div>
  </div>
<header class="header" data-header>
  <div class="container">
    <a href="#" class="logo">
      <img src="./assets/images/logo.svg" width="160" height="50" alt="Grilli - Home">
    </a>

    <nav class="navbar" data-navbar>
      <button class="close-btn" aria-label="close menu" data-nav-toggler>
        <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
      </button>

      <a href="#" class="logo">
        <img src="./assets/images/logo.svg" width="160" height="50" alt="Grilli - Home">
      </a>

      <ul class="navbar-list">
        <li class="navbar-item">
          <a href="index.php" class="navbar-link hover-underline active">
            <div class="separator"></div>
            <span class="span">Home</span>
          </a>
        </li>
       <li class="navbar-item">
  <a href="index.php#menu" class="navbar-link hover-underline">
    <div class="separator"></div>
    <span class="span">Menus</span>
  </a>
</li>


        <li class="navbar-item">
          <a href="index.php#promotion" class="navbar-link hover-underline">
            <div class="separator"></div>
            <span class="span">Promotion</span>
          </a>
        </li>
        <li class="navbar-item">
          <a href="index.php#packages" class="navbar-link hover-underline">
            <div class="separator"></div>
            <span class="span">Packages</span>
          </a>
        </li>
        <li class="navbar-item dropdown">
          <a href="#" class="navbar-link hover-underline dropdown-toggle">
            <div class="separator"></div>
            <span class="span">Orders</span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="new_order.php?customer_id=<?php echo urlencode(htmlspecialchars($customer_id)); ?>">Order</a></li>
            <li><a href="order_history.php?customer_id=<?php echo urlencode(htmlspecialchars($customer_id)); ?>">History</a></li>
          </ul>
        </li>
      </ul>

      <div class="text-center">
        <p class="headline-1 navbar-title">Visit Us</p>
        <address class="body-4">
          Restaurant St, Delicious City, <br>
          London 9578, UK
        </address>
        <p class="body-4 navbar-text">Open: 9.30 am - 2.30pm</p>
        <a href="mailto:booking@grilli.com" class="body-4 sidebar-link">booking@grilli.com</a>
        <div class="separator"></div>
        <p class="contact-label">Booking Request</p>
        <a href="tel:+88123123456" class="body-1 contact-number hover-underline">
          +88-123-123456
        </a>
      </div>
    </nav>

   

<div></div>
<!-- Cart image placed directly under the Login/Logout button -->
<div style='text-align: center; margin-top: 10px;'>
    <a href='cart.php'>
        <img src='./assets/images/buy.png' style='width:80px; display: block; margin: 0 auto; margin-left: auto;'>
        <span>Cart-Box</span>
    </a>
</div>

</div></header>







  <main>
    <article>

 
   
<?php
// The PHP code block remains unchanged

include 'connection.php';


// Retrieve package_id from URL
$package_id = isset($_GET['package_id']) ? (int)$_GET['package_id'] : null;

// Retrieve customer_id from session
$customer_id = isset($_SESSION['customer_id']) ? (int)$_SESSION['customer_id'] : null;

if ($package_id) {
    // SQL query to fetch data based on package_id
    $sql = "
        SELECT
            p.product_name,
            MIN(pp.photo_path) AS photo_path,
            p.product_price,
            p.product_des,
            COALESCE(cr.average_rating, 0) AS average_rating,
            p.product_id,
            promo.promotion_percent
        FROM
            package_product pkpk
        LEFT JOIN
            product p ON pkpk.product_id = p.product_id
        LEFT JOIN
            product_photo pp ON p.product_id = pp.product_id
        LEFT JOIN
            (SELECT product_id, AVG(rating) AS average_rating FROM customer_rating GROUP BY product_id) cr
            ON p.product_id = cr.product_id
        LEFT JOIN
            promotion promo ON p.product_id = promo.product_id
        WHERE
            pkpk.package_id = ?
        GROUP BY
            p.product_id
    ";

    // Prepare and execute the query
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $package_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Start HTML container for cards
            echo "<div class='container' style='margin-top:200px;'>";

            // CSS for consistent card layout
            echo "<style>
    .container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Creates a grid with responsive column sizes */
        gap: 20px; /* Space between grid items */
       
    }
    .card {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
    }
    .card img {
      max-width: 100%;
      height: 200px; /* Set a fixed height for all images */
      object-fit: cover; /* Ensure images cover the area without stretching */
      border-radius: 5px;
  }
    .card h3 {
        margin: 10px 0;
    }
    .card .price {
        margin: 10px 0;
        font-weight: bold;
    }
    .card .rating {
        margin: 10px 0;
        color: #f39c12;
    }
    .card .btn {
        margin-top: auto; /* Pushes button to the bottom of the card */
    }
    .card .product-info {
        flex-grow: 1; /* Makes the product info section grow to fill space */
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
</style>
";

            // Fetch and display rows
            while ($row = $result->fetch_assoc()) {
                // Calculate the number of full and empty stars
                $rating = (int)$row['average_rating'];
                $fullStars = str_repeat("★", $rating);
                $emptyStars = str_repeat("☆", 5 - $rating);

                // Determine if there is a promotion and calculate the price
                $originalPrice = (float)$row['product_price'];
                $promotionPercent = isset($row['promotion_percent']) ? (float)$row['promotion_percent'] : null;

                if ($promotionPercent !== null) {
                    // Calculate new price with promotion
                    $newPrice = $originalPrice - ($originalPrice * ($promotionPercent / 100));
                    $priceDisplay = "
                        <div><del>$" . htmlspecialchars(number_format($originalPrice, 2)) . "</del></div>
                         $" . htmlspecialchars(number_format($newPrice, 2));
                } else {
                    // No promotion, show normal price
                    $priceDisplay = "$" . htmlspecialchars(number_format($originalPrice, 2));
                }

                // Construct the URL for the product
                $viewProductsUrl = "order.php?package_id=" . urlencode($package_id) . "&product_id=" . urlencode($row['product_id']) . "&customer_id=" . urlencode($customer_id);

                echo "<div class='card'>
               
                    <img src='" . htmlspecialchars($row['photo_path']) . "' alt='" . htmlspecialchars($row['product_name']) . "'>
                    <div class='product-info'>
                        <h3>" . htmlspecialchars($row['product_name']) . "</h3>
                        <p class='price'>" . $priceDisplay . "</p>
                        <p>" . htmlspecialchars($row['product_des']) . "</p>
                        <p class='rating'>" . $fullStars . $emptyStars . "</p>
                    </div>
                    <a href='" . $viewProductsUrl . "' class='btn btn-primary'>
                        View Product
                    </a>
                </div>";
            }

            // End HTML container for cards
            echo "</div>";
        } else {
            echo '<h1 style="margin-top:200px;">No records found for package ' . htmlspecialchars($package_id) . '</h1>';
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . htmlspecialchars($conn->error);
    }
} else {
    echo "Invalid package ID.";
}

$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


</body>
</html>

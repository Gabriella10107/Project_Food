<?php
session_start(); // Start the session
error_reporting(1);
// Include database connection
include('connection.php');

// Create tables if they don't exist
$sql_create_tables = "
CREATE TABLE IF NOT EXISTS `order_customer` (
    `order_id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_token` VARCHAR(255) UNIQUE,
    `total_price` DECIMAL(10, 2),
    `order_date` DATETIME,
    `end_date` DATETIME,
    `customer_id` INT,
    `active` TINYINT(1) DEFAULT 1,
    `discount_id` INT DEFAULT NULL,
    `discount_price` DECIMAL(10, 2) DEFAULT NULL,
    FOREIGN KEY (`customer_id`) REFERENCES `customer`(`customer_id`) ON DELETE CASCADE,
    FOREIGN KEY (`discount_id`) REFERENCES `discount`(`discount_id`) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS `customer_product` (
    `customer_order_id` INT AUTO_INCREMENT PRIMARY KEY,
    `quantity` INT,
    `product_id` INT,
    `order_id` INT,
    `active_product` TINYINT(1) DEFAULT 1,
    FOREIGN KEY (`product_id`) REFERENCES `product`(`product_id`) ON DELETE CASCADE,
    FOREIGN KEY (`order_id`) REFERENCES `order_customer`(`order_id`) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS `cart` (
    `cart_id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT,
    `product_id` INT,
    `quantity` INT,
    `total_price` DECIMAL(10, 2),
    FOREIGN KEY (`customer_id`) REFERENCES `customer`(`customer_id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `product`(`product_id`) ON DELETE CASCADE
);
";

if ($conn->multi_query($sql_create_tables)) {
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
        if ($conn->errno) {
            echo "Error creating tables: " . $conn->error;
        }
    } while ($conn->more_results() && $conn->next_result());
}

$error_message = '';
$success_message = '';

// Retrieve customer_id from URL or session
$customer_id = isset($_GET['customer_id']) ? htmlspecialchars($_GET['customer_id']) : (isset($_SESSION['customer_id']) ? $_SESSION['customer_id'] : null);

// Check if the customer is logged in
$is_logged_in = !empty($customer_id);

if (!$is_logged_in) {
    header("Location: login.php");
    exit();
}

// Fetch cart items
$cart_items = [];
$total_price = 0.00; // Initialize total price
if ($customer_id) {
    $sql_fetch_cart = "SELECT c.cart_id, p.product_name, p.product_price, pp.photo_path, c.quantity, c.total_price, c.product_id
                       FROM cart c
                       JOIN product p ON c.product_id = p.product_id
                       JOIN product_photo pp ON c.product_id = pp.product_id
                       WHERE c.customer_id = $customer_id";
    $result = $conn->query($sql_fetch_cart);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cart_items[] = $row;
            $total_price += $row['total_price']; // Accumulate total price
        }
    } else {
        $error_message = "Cart is empty.";
    }
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_cart_item'])) {
    $cart_id = intval($_POST['cart_id']);

    $sql_delete_item = "DELETE FROM cart WHERE cart_id = $cart_id";
    if ($conn->query($sql_delete_item) === TRUE) {
        // Refresh cart items
        $cart_items = [];
        $total_price = 0.00;
        $result = $conn->query($sql_fetch_cart);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $cart_items[] = $row;
                $total_price += $row['total_price']; // Accumulate total price
            }
        } else {
            $error_message = "Cart is empty.";
        }
    } else {
        $error_message = "Error removing item from cart: " . $conn->error;
    }
}

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $order_token = generateOrderToken(); // Generate a random 12-digit order token
    $end_date = date('Y-m-d H:i:s', strtotime('+7 days'));
    $discount_id = NULL;
    $discount_price = $total_price; // Initialize discount_price as total_price

    // Check for applicable discount
    $sql_check_discount = "SELECT discount_id, discount_amount, discount_percentage FROM discount WHERE discount_amount IS NOT NULL";
    $discount_result = $conn->query($sql_check_discount);

    if ($discount_result && $discount_result->num_rows > 0) {
        while ($discount = $discount_result->fetch_assoc()) {
            if ($total_price >= $discount['discount_amount']) {
                $discount_id = intval($discount['discount_id']);
                // Calculate discount based on percentage
                $discount_percentage = $discount['discount_percentage'];
                if ($discount_percentage) {
                    $discount_amount = ($total_price * $discount_percentage) / 100;
                    $discount_price = $total_price - $discount_amount;
                }
                break;
            }
        }
    }

    $sql_insert_order = "INSERT INTO order_customer (order_token, total_price, order_date, end_date, customer_id, active, discount_id, discount_price)
                         VALUES ('$order_token', '$total_price', NOW(), '$end_date', $customer_id, 1, " . ($discount_id ? $discount_id : "NULL") . ", " . ($discount_id ? "'$discount_price'" : "NULL") . ")";

    if ($conn->query($sql_insert_order) === TRUE) {
        $order_id = $conn->insert_id;

        foreach ($cart_items as $item) {
            if (isset($item['product_id']) && isset($item['quantity']) && isset($item['total_price'])) {
                $sql_insert_product = "INSERT INTO customer_product (quantity, product_id, order_id, active_product)
                                       VALUES ({$item['quantity']}, {$item['product_id']}, $order_id, 1)";
                if (!$conn->query($sql_insert_product)) {
                    $error_message = "Error inserting product: " . $conn->error;
                    break;
                }
            } else {
                $error_message = "Missing product details.";
                break;
            }
        }

        if (empty($error_message)) {
            $sql_clear_cart = "DELETE FROM cart WHERE customer_id = $customer_id";
            $conn->query($sql_clear_cart);

            $success_message = "Order placed successfully!";

            echo "<script>setTimeout(function() { window.location.href = 'success.php?order_id=" . urlencode($order_id) . "'; }, 2000);</script>";
        }
    } else {
        $error_message = "Error placing order: " . $conn->error;
    }
}

// Function to generate a random 12-digit token
function generateOrderToken($length = 12) {
    $characters = '0123456789';
    $token = '';
    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $token;
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            position: relative; /* Add this line to position the back button */
        }
        h1 {
            color: #333;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 2em;
            position: relative; /* Positioning context for the back button */
        }
        .back-btn {
            position: absolute;
            margin-top: 10px;
            right: 40px;
            background-color: #3498db;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }
        .back-btn:hover {
            background-color: #2980b9;
        }
        .success-message, .error-message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            color: #fff;
            text-align: center;
        }
        .success-message {
            background-color: #2ecc71;
        }
        .error-message {
            background-color: #e74c3c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #3498db;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        button {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #c0392b;
        }
        .product-image {
            width: 100px; /* Adjust size as needed */
            height: auto;
        }

        .checkout-container {
    margin-left: 990px;
}

.total-price-container {
    margin-left: 1000px;
}

    </style>
</head>
<body>
    <div class="container">
        <a href="index.php?customer_id=<?php echo urlencode($customer_id); ?>" class="back-btn">Back to Home</a>

        <h1>Cart</h1>

        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if ($cart_items): ?>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo number_format($item['product_price'], 2); ?></td>
                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                            <td><?php echo number_format($item['total_price'], 2); ?></td>
                            <td>
                                <?php if (!empty($item['photo_path'])): ?>
                                    <img src="<?php echo htmlspecialchars($item['photo_path']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" class="product-image">
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="cart_id" value="<?php echo htmlspecialchars($item['cart_id']); ?>">
                                    <button type="submit" name="delete_cart_item">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

           <div class="total-price-container">
            <p><strong>Total Price:</strong> <?php echo number_format($total_price, 2); ?></p>
        </div>

        <div class="checkout-container">
            <form method="post" action="">
                <button type="submit" name="checkout">Checkout</button>
            </form>
        </div>
        <?php else: ?>
            <p>No items in cart.</p>
        <?php endif; ?>
    </div>
</body>
</html>

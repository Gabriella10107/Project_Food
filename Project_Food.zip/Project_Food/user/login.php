<?php
include('connection.php');
session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['customer_email'];
    $password = $_POST['customer_password'];

    // Prepare and execute the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM customer WHERE customer_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, verify password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['customer_password'])) {
            // Successful login, set session variables
            $_SESSION['customer_email'] = $email;
            $_SESSION['customer_id'] = $row['customer_id']; // Store customer_id in session

            // Redirect to index.php with customer_id in URL
            header("Location: index.php?customer_id=" . urlencode($row['customer_id']));
            exit();
        } else {
            $error_message = "Incorrect password.";
        }
    } else {
        $error_message = "Email not registered.";
    }

    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royal Login</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background: linear-gradient(to right, #b993d6, #8ca6db);
            margin: 0;
            padding: 0;
            color: #fff;
        }
        .container {
            width: 80%;
            max-width: 400px;
            margin: 50px auto;
            padding: 30px;
            background: rgba(0, 0, 0, 0.8);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.5);
            border-radius: 15px;
            border: 2px solid gold;
            text-align: center;
        }
        h2 {
            color: gold;
            margin-bottom: 20px;
            font-size: 28px;
            font-weight: bold;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 16px;
            color: gold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 8px;
            background: #444;
            color: #fff;
            font-size: 16px;
        }
        .form-group input[type="submit"] {
            background: gold;
            color: #000;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            font-size: 18px;
        }
        .form-group input[type="submit"]:hover {
            background: #ffcc00;
            transform: scale(1.05);
        }
        .error-message {
            color: #ff4d4d;
            margin: 15px 0;
            font-weight: bold;
        }
        p {
            margin-top: 20px;
            font-size: 16px;
        }
        a {
            color: gold;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="customer_email" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="customer_password" required>
            </div>

            <div class="form-group">
                <input type="submit" value="Login">
            </div>

            <?php if (isset($error_message)): ?>
                <div class="error-message">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
        </form>

        <p>Don't have an account? <a href="sign_up.php">Sign up here</a>.</p>
    </div>
</body>
</html>

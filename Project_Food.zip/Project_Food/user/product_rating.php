<?php
session_start(); // Start the session

// Retrieve customer_id from session
$customer_id = isset($_SESSION['customer_id']) ? (int)$_SESSION['customer_id'] : 0;

// Check if the customer is logged in
if (empty($customer_id)) {
    header("Location: login.php");
    exit();
}

// Include database connection
include('connection.php');

// Function to create the customer_rating table if it doesn't exist
function createCustomerRatingTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS customer_rating (
        rating_id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        customer_id INT NOT NULL,
        rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
        review TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES order_customer(order_id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES product(product_id) ON DELETE CASCADE,
        FOREIGN KEY (customer_id) REFERENCES customer(customer_id) ON DELETE CASCADE
    )";

    if ($conn->query($sql) === TRUE) {
        // Table created or already exists
    } else {
        die('Error creating table: ' . htmlspecialchars($conn->error));
    }
}

// Create the table
createCustomerRatingTable($conn);

// Initialize variables
$show_message = false;

// Handle form submission for ratings and reviews
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rate_order'])) {
    $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    $review = isset($_POST['review']) ? trim($_POST['review']) : '';

    // Validate input
    if ($rating < 1 || $rating > 5) {
        die('Invalid rating.');
    }

    // Insert rating and review into the database
    $rating_sql = "INSERT INTO customer_rating (order_id, product_id, customer_id, rating, review) 
                   VALUES (?, ?, ?, ?, ?)";
    $rating_stmt = $conn->prepare($rating_sql);

    if ($rating_stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $rating_stmt->bind_param('iiiss', $order_id, $product_id, $customer_id, $rating, $review);

    if ($rating_stmt->execute()) {
        $show_message = true; // Set flag to show message
    } else {
        die('Execute failed: ' . htmlspecialchars($rating_stmt->error));
    }

    $rating_stmt->close();
}

// Retrieve product information
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

$product_sql = "SELECT p.product_name, pp.photo_path
                FROM product p 
                JOIN product_photo pp ON p.product_id = pp.product_id
                WHERE p.product_id = ?";
$product_stmt = $conn->prepare($product_sql);

if ($product_stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$product_stmt->bind_param('i', $product_id);

if (!$product_stmt->execute()) {
    die('Execute failed: ' . htmlspecialchars($product_stmt->error));
}

$product_result = $product_stmt->get_result();
$product = $product_result->fetch_assoc();

if (!$product) {
    die('Product not found.');
}

$product_stmt->close();
$conn->close();
?>
<?php
// Include database connection
include('connection.php');

// Function to update the average rating for each product
function updateAverageRating($conn) {
    // Calculate the average rating for each product_id
    $avg_rating_sql = "SELECT product_id, AVG(rating) as average_rating FROM customer_rating GROUP BY product_id";
    $avg_rating_result = $conn->query($avg_rating_sql);

    if ($avg_rating_result === false) {
        die('Error calculating average rating: ' . htmlspecialchars($conn->error));
    }

    // Update the average_rating column in the product table
    while ($row = $avg_rating_result->fetch_assoc()) {
        $product_id = $row['product_id'];
        $average_rating = $row['average_rating'];

        $update_sql = "UPDATE product SET average_rating = ? WHERE product_id = ?";
        $update_stmt = $conn->prepare($update_sql);

        if ($update_stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }

        $update_stmt->bind_param('di', $average_rating, $product_id);

        if (!$update_stmt->execute()) {
            die('Execute failed: ' . htmlspecialchars($update_stmt->error));
        }

        $update_stmt->close();
    }
}

// Call the function to update average ratings
updateAverageRating($conn);

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f9f9f9;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .header {
            background: #4CAF50;
            color: #fff;
            padding: 20px 0;
            width: 100%;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .header h1 {
            margin: 0;
            font-size: 28px;
        }
        .container {
            width: 90%;
            max-width: 800px;
            margin: 80px auto 30px auto;
            padding: 0 20px;
        }
        .rating-form {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px auto;
            text-align: center;
        }
        .rating-form img {
            border-radius: 4px;
            width: 150px;
            height: 150px;
        }
        .rating-form h2 {
            margin-bottom: 10px;
            font-size: 24px;
        }
        .rating-form form {
            margin-top: 20px;
        }
        .rating-form label {
            display: block;
            margin: 10px 0 5px;
        }
        .rating-form select, .rating-form textarea, .rating-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin: 10px 0;
        }
        .rating-form input[type="submit"] {
            background: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .rating-form input[type="submit"]:hover {
            background: #45a049;
        }

        /* Star rating CSS */
        .rating-stars {
            display: inline-flex;
            direction: rtl;
            font-size: 0;
            margin: 10px 0;
            justify-content: center;
        }

        .rating-stars input[type="radio"] {
            display: none;
        }

        .rating-stars label {
            font-size: 24px;
            color: #ddd;
            cursor: pointer;
            transition: color 0.2s ease;
            padding: 0 2px;
        }

        .rating-stars input[type="radio"]:checked ~ label {
            color: #ffcc00;
        }

        .rating-stars input[type="radio"]:checked ~ label:hover,
        .rating-stars input[type="radio"]:checked ~ label:hover ~ label {
            color: #ffcc00;
        }

        .rating-stars input[type="radio"]:checked ~ input[type="radio"]:not(:checked) ~ label,
        .rating-stars input[type="radio"]:not(:checked) ~ label:hover,
        .rating-stars input[type="radio"]:not(:checked) ~ label:hover ~ label {
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Rate Product</h1>
    </div>
    <div class="container">
        <div class="rating-form">
            <h2>Rate the Product</h2>
            <img src="<?php echo htmlspecialchars($product['photo_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>">
            <form method="post" action="">
                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order_id); ?>">
                <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">

                <label for="rating">Rating:</label>
                <div class="rating-stars">
                    <input type="radio" id="star5" name="rating" value="5" required>
                    <label for="star5" title="5 stars">★</label>
                    <input type="radio" id="star4" name="rating" value="4">
                    <label for="star4" title="4 stars">★</label>
                    <input type="radio" id="star3" name="rating" value="3">
                    <label for="star3" title="3 stars">★</label>
                    <input type="radio" id="star2" name="rating" value="2">
                    <label for="star2" title="2 stars">★</label>
                    <input type="radio" id="star1" name="rating" value="1">
                    <label for="star1" title="1 star">★</label>
                </div>

                <label for="review">Review:</label>
                <textarea name="review" id="review" rows="4" placeholder="Write your review here..."></textarea>
                
                <input type="submit" name="rate_order" value="Submit Rating">
            </form>
            <a href="order_history.php">
                <button style="width: 760px; padding: 10px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Back to Order History
                </button>
            </a>
            <?php if ($show_message): ?>
                <p>Thank you for your feedback!</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

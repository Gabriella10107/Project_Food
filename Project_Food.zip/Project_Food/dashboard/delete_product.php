<?php
include('connection.php');

$error_message = '';
$success_message = '';

// Get product ID and other parameters from query string
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
$menu_id = isset($_GET['menu_id']) ? intval($_GET['menu_id']) : 0;
$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

if ($product_id) {
    $conn->begin_transaction();

    // Fetch photo paths
    $sql_photo = "SELECT photo_path FROM product_photo WHERE product_id = ?";
    $stmt_photo = $conn->prepare($sql_photo);
    $stmt_photo->bind_param("i", $product_id);
    $stmt_photo->execute();
    $photo_result = $stmt_photo->get_result()->fetch_all(MYSQLI_ASSOC);

    // Delete photo files from server
    foreach ($photo_result as $photo) {
        if (file_exists($photo['photo_path'])) {
            unlink($photo['photo_path']);
        }
    }
    $stmt_photo->close();

    // Delete product photos from database
    $sql_product_photo = "DELETE FROM product_photo WHERE product_id = ?";
    $stmt_product_photo = $conn->prepare($sql_product_photo);
    $stmt_product_photo->bind_param("i", $product_id);

    if ($stmt_product_photo->execute()) {
        // Delete product from database
        $sql_product = "DELETE FROM product WHERE product_id = ?";
        $stmt_product = $conn->prepare($sql_product);
        $stmt_product->bind_param("i", $product_id);

        if ($stmt_product->execute()) {
            $conn->commit();
            $success_message = "Product and associated photos deleted successfully.";
            // Redirect to product page with query parameters
            header("Location: product.php?menu_id={$menu_id}&category_id={$category_id}");
            exit();
        } else {
            $conn->rollback();
            $error_message = "Error deleting product: " . $stmt_product->error;
        }
        
        $stmt_product->close();
    } else {
        $conn->rollback();
        $error_message = "Error deleting product photos: " . $stmt_product_photo->error;
    }
    
    $stmt_product_photo->close();
    $conn->close();
} else {
    $error_message = "Invalid product ID.";
}

// Display error or success messages if not redirected
if (!empty($error_message)) {
    echo "<div class='alert alert-danger'>{$error_message}</div>";
} elseif (!empty($success_message)) {
    echo "<div class='alert alert-success'>{$success_message}</div>";
}
?>

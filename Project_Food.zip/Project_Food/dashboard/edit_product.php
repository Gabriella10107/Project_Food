<?php
// Include database connection
include('connection.php');

// Initialize error and success message variables
$error_message = '';
$success_message = '';

$menu_id = isset($_GET['menu_id']) ? intval($_GET['menu_id']) : 0;
$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

// Fetch product data from database if needed for editing
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
// Validate product ID
if ($product_id <= 0) {
    $error_message = "Invalid product ID.";
} else {
    // Fetch existing product and photo data
    $sql = "SELECT p.*, COALESCE(pp.photo_path, 'default_image_path.jpg') AS photo_path 
            FROM product p 
            LEFT JOIN product_photo pp ON p.product_id = pp.product_id 
            WHERE p.product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $product = $result->fetch_assoc();
        $old_photo_path = $product['photo_path']; // Store old image path
    } else {
        $error_message = "Product not found.";
    }
    $stmt->close();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'];
    $product_des = $_POST['product_des'];
    $product_price = $_POST['product_price'];
    $photo_path = $old_photo_path; // Default to existing path

    // Handle file upload if a new image is provided
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'product_img/';
        $uploaded_file = $upload_dir . basename($_FILES['product_image']['name']);
        
        // Validate and move the uploaded file
        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $uploaded_file)) {
            // Delete the old image file if it's not the default image
            if ($old_photo_path != 'default_image_path.jpg' && file_exists($old_photo_path)) {
                unlink($old_photo_path);
            }
            $photo_path = $uploaded_file;
        } else {
            $error_message = "Error uploading the image.";
        }
    }

    // Validate input
    if (empty($product_name) || empty($product_des) || empty($product_price)) {
        $error_message = "All fields are required.";
    } else {
        // Update product data in the database
        $sql = "UPDATE product p 
                LEFT JOIN product_photo pp ON p.product_id = pp.product_id 
                SET p.product_name = ?, p.product_des = ?, p.product_price = ?, pp.photo_path = ? 
                WHERE p.product_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdsi", $product_name, $product_des, $product_price, $photo_path, $product_id);
        if ($stmt->execute()) {
            $success_message = "Product updated successfully.";
            // Redirect to product.php with menu_id and category_id
            header("Location: product.php?menu_id=$menu_id&category_id=$category_id");
            exit();
        } else {
            $error_message = "Error updating product: " . $conn->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="path_to_your_css_file.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input, 
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input[type="file"] {
            padding: 3px;
        }

        .form-group img {
            display: block;
            margin: 10px auto; /* Center the image */
            max-width: 50%; /* Make the image smaller */
            border-radius: 4px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 12px 20px;
            border: none;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-bottom: 15px;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            width: 94%;
            background-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Edit Product</h1>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php elseif (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (!empty($product)): ?>
        <form action="edit_product.php?product_id=<?php echo htmlspecialchars($product['product_id']); ?>&menu_id=<?php echo htmlspecialchars($menu_id); ?>&category_id=<?php echo htmlspecialchars($category_id); ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" name="product_name" id="product_name" class="form-control" value="<?php echo htmlspecialchars($product['product_name']); ?>">
            </div>
            <div class="form-group">
                <label for="product_des">Description:</label>
                <textarea name="product_des" id="product_des" class="form-control"><?php echo htmlspecialchars($product['product_des']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="product_price">Price:</label>
                <input type="number" step="0.01" name="product_price" id="product_price" class="form-control" value="<?php echo htmlspecialchars($product['product_price']); ?>">
            </div>
            <div class="form-group">
                <label for="product_image">Product Image:</label><br>
                <img src="<?php echo htmlspecialchars($product['photo_path']); ?>" alt="Product Image"><br>
                <input type="file" name="product_image" id="product_image" class="form-control-file">
            </div>
            <button type="submit" class="btn mt-3">Update Product</button>
            <a href="product.php?menu_id=<?php echo htmlspecialchars($menu_id); ?>&category_id=<?php echo htmlspecialchars($category_id); ?>" class="btn btn-secondary mt-3">Back</a>
        </form>
    <?php endif; ?>
</div>
</body>
</html>

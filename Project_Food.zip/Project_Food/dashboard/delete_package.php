<?php
// Include database connection
include('connection.php');

// Check if package_id is set in the URL
if (isset($_GET['package_id'])) {
    $package_id = intval($_GET['package_id']);

    // Prepare SQL statement to get package details
    $sql_select = "SELECT package_photo FROM package WHERE package_id = ?";
    $stmt_select = $conn->prepare($sql_select);
    $stmt_select->bind_param("i", $package_id);
    $stmt_select->execute();
    $result = $stmt_select->get_result();

    if ($result->num_rows > 0) {
        // Fetch package photo path
        $row = $result->fetch_assoc();
        $package_photo = $row['package_photo'];

        // Prepare SQL statement to delete the package record
        $sql_delete = "DELETE FROM package WHERE package_id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $package_id);

        if ($stmt_delete->execute()) {
            // Check if package photo exists and delete it
            if (!empty($package_photo) && file_exists($package_photo)) {
                unlink($package_photo);
            }

            // Close statements and connection
            $stmt_delete->close();
            $stmt_select->close();
            $conn->close();

            // Redirect to the package list page with a success message
            header("Location: package.php?message=Package deleted successfully");
            exit();
        } else {
            echo "<div class='error-message'>Error deleting package: " . $stmt_delete->error . "</div>";
        }
    } else {
        echo "<div class='error-message'>Package not found.</div>";
    }
} else {
    echo "<div class='error-message'>Invalid request.</div>";
}
?>

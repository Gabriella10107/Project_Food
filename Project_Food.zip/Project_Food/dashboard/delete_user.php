<?php
// Include database connection
include('connection.php');

// Check if customer_id is set in the URL
if (isset($_GET['customer_id'])) {
    $customer_id = $_GET['customer_id'];

    // Prepare the SQL DELETE statement
    $sql_delete = "DELETE FROM customer WHERE customer_id = ?";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql_delete)) {
        // Bind the customer_id parameter to the SQL query
        $stmt->bind_param("i", $customer_id);

        // Execute the statement
        if ($stmt->execute()) {
            // Close the statement
            $stmt->close();
            
            // Close the database connection
            $conn->close();
            
            // Show a success message with a script
            echo "<script>
                    alert('Customer deleted successfully');
                    window.location.href = 'view_user.php';
                  </script>";
            exit();
        } else {
            // Display an error message if the execution fails
            echo "Error: Could not execute the delete statement.";
        }

        // Close the statement
        $stmt->close();
    } else {
        // Display an error message if the statement preparation fails
        echo "Error: Could not prepare the delete statement.";
    }
} else {
    // Display an error message if customer_id is not set in the URL
    echo "Error: Invalid customer ID.";
}

// Close the database connection
$conn->close();
?>

<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
include('connection.php');

// Check if product_id is provided
if (isset($_GET['product_id'])) {
    $delete_id = intval($_GET['product_id']);

    // Check if delete_id is valid
    if ($delete_id > 0) {
        // Begin transaction
        $conn->begin_transaction();

        try {
            // Delete from promotion
            $delete_promotion_sql = "DELETE FROM promotion WHERE product_id = ?";
            if ($stmt = $conn->prepare($delete_promotion_sql)) {
                $stmt->bind_param("i", $delete_id);
                $stmt->execute();
                $stmt->close();

                // Commit transaction
                $conn->commit();

                // Redirect to promotion.php with success message
                header("Location: promotion.php");
                exit();
            } else {
                // Rollback transaction if prepare fails
                $conn->rollback();
                header("Location: promotion.php?status=error&message=Failed to prepare SQL statement.");
                exit();
            }
        } catch (Exception $e) {
            // Rollback transaction in case of error
            $conn->rollback();
            header("Location: promotion.php?status=error&message=" . urlencode("Error deleting promotion: " . $e->getMessage()));
            exit();
        }
    } else {
        header("Location: promotion.php?status=error&message=Invalid delete ID.");
        exit();
    }
} else {
    header("Location: promotion.php?status=error&message=No product ID specified.");
    exit();
}

// Close connection
$conn->close();
?>

<?php
// Display messages based on URL parameters
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
    echo "<div class='alert alert-info'>$message</div>";
}
?>





<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_id = $_POST['category_id'];

    // Database connection
   include('connection.php');

    // Prepare the DELETE statement
    $stmt = $conn->prepare("DELETE FROM category WHERE category_id = ?");
    $stmt->bind_param("i", $category_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Category and its related data deleted successfully.";
    } else {
        echo "Error deleting category: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Redirect back to the category list
    header("Location: delete_category_display.php");
    exit();
}
?>
 
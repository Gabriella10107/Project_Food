<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
include('connection.php');

// Initialize variables
$successMessage = '';
$errorMessage = '';

// Create the table if it doesn't exist (updated)
$table_creation_query = "
CREATE TABLE IF NOT EXISTS discount (
    discount_id INT AUTO_INCREMENT PRIMARY KEY,
    discount_amount DECIMAL(10, 2) NULL,
    discount_percentage DECIMAL(5, 2) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if (!$conn->query($table_creation_query)) {
    die("Table creation failed: " . $conn->error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_discount'])) {
        $discount_amount = isset($_POST['discount_amount']) ? floatval($_POST['discount_amount']) : NULL;
        $discount_percentage = isset($_POST['discount_percentage']) ? floatval($_POST['discount_percentage']) : NULL;

        // Validate that one of the discount types is set
        if ($discount_amount === NULL && $discount_percentage === NULL) {
            $errorMessage = "Please provide either a discount amount or percentage.";
        } else {
            // Prepare and execute SQL query
            $stmt = $conn->prepare("INSERT INTO discount (discount_amount, discount_percentage) VALUES (?, ?)");
            $stmt->bind_param("dd", $discount_amount, $discount_percentage);

            if ($stmt->execute()) {
                $successMessage = "Discount created successfully!";
                $stmt->close();
                // Redirect to avoid resubmission
                header('Location: create_discount.php');
                exit();
            } else {
                $errorMessage = "Error: " . $stmt->error;
            }

            $stmt->close();
        }
    } elseif (isset($_POST['delete_discount'])) {
        $discount_id = intval($_POST['discount_id']);

        // Prepare and execute SQL query
        $stmt = $conn->prepare("DELETE FROM discount WHERE discount_id = ?");
        $stmt->bind_param("i", $discount_id);

        if ($stmt->execute()) {
            $successMessage = "Discount deleted successfully!";
            $stmt->close();
            // Redirect to avoid resubmission
            header('Location: create_discount.php');
            exit();
        } else {
            $errorMessage = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Fetch all discounts from the database
$sql_fetch_discounts = "SELECT * FROM discount";
$result = $conn->query($sql_fetch_discounts);

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Discounts</title>
    <style>
        /* Form container styles */
        .form-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container label {
            display: block;
            margin: 10px 0 5px;
        }

        .form-container input[type="number"],
        .form-container input[type="submit"],
        .form-container .btn-primary {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            box-sizing: border-box;
            border-radius: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            transition: background-color 0.3s;
        }

        .form-container input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        .form-container input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .message {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid;
            border-radius: 5px;
        }

        .success {
            border-color: #28a745;
            color: #28a745;
        }

        .error {
            border-color: #dc3545;
            color: #dc3545;
        }

        /* Table styles */
        .table-container {
            margin: 20px auto;
            max-width: 800px;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
        }

        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-container th,
        .table-container td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table-container th {
            background-color: #f4f4f4;
        }

        .btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        .btn:hover {
            background-color: #c82333;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            display: block;
            text-decoration: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="form-container">
            <h2>Create Discount</h2>
            <?php
            if ($successMessage) {
                echo "<div class='message success'>$successMessage</div>";
            }
            if ($errorMessage) {
                echo "<div class='message error'>$errorMessage</div>";
            }
            ?>
            <form action="" method="POST">
                <label for="discount_amount">Discount Amount:</label>
                <input type="number" step="0.01" id="discount_amount" name="discount_amount">
                <label for="discount_percentage">Discount Percentage:</label>
                <input type="number" step="0.01" id="discount_percentage" name="discount_percentage">
                <input type="submit" name="create_discount" value="Create Discount">
            </form>
            <a href='index.php' class='btn-primary'>Back</a>
        </div>

        <!-- Display discounts table -->
        <div class="table-container">
            <h2>Discounts List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Discount ID</th>
                        <th>Discount Amount</th>
                        <th>Discount Percentage</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['discount_id']}</td>
                                <td>{$row['discount_amount']}</td>
                                <td>{$row['discount_percentage']}</td>
                                <td>{$row['created_at']}</td>
                                <td>
                                    <form action='' method='POST' style='display:inline;'>
                                        <input type='hidden' name='discount_id' value='{$row['discount_id']}'>
                                        <input type='submit' name='delete_discount' value='Delete' class='btn' onclick=\"return confirm('Are you sure you want to delete this discount?');\">
                                    </form>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No discounts found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

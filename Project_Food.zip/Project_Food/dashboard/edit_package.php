<?php
// Include the database connection file
include('connection.php');

// Check if package_id is provided
if (!isset($_GET['package_id']) || !is_numeric($_GET['package_id'])) {
    header("Location: package.php");
    exit();
}

$package_id = intval($_GET['package_id']);

// Retrieve package details from the database
$sql = "SELECT * FROM package WHERE package_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $package_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Package not found.";
    exit();
}

$package = $result->fetch_assoc();
$stmt->close();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $package_name = trim($_POST['package_name']);
    $package_des = trim($_POST['package_des']);

    // Validate inputs
    if (empty($package_name) || empty($package_des)) {
        echo "All fields are required.";
        exit();
    }

    $package_photo = $package['package_photo']; // Keep the old photo by default

    // Handle file upload if a new file is selected
    if (!empty($_FILES["package_photo"]["name"])) {
        // Create the uploads directory if it doesn't exist
        $target_dir = "../dashboard/upload_package/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        // Full path for the new image
        $target_file = $target_dir . basename($_FILES["package_photo"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Validate file size (e.g., 5MB max)
        if ($_FILES["package_photo"]["size"] > 5000000) {
            echo "Sorry, your file is too large.";
            exit();
        }

        // Validate file type
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($imageFileType, $allowed_types)) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit();
        }

        // Delete old photo if it exists
        if (!empty($package['package_photo']) && file_exists($package['package_photo'])) {
            unlink($package['package_photo']);
        }

        // Move uploaded file
        if (move_uploaded_file($_FILES["package_photo"]["tmp_name"], $target_file)) {
            $package_photo = $target_file;
        } else {
            echo "Error uploading file.";
            exit();
        }
    }

    // Update the package in the database using prepared statements
    $sql = "UPDATE package SET 
                package_name = ?, 
                package_des = ?, 
                package_photo = ?
            WHERE package_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $package_name, $package_des, $package_photo, $package_id);

    if ($stmt->execute()) {
        // Redirect to package.php after successful update
        header("Location: package.php");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Package</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px; /* Adjust the max width as needed */
            margin: 0 auto;   /* Center the form horizontally */
        }
        .btn-right {
            float: right; /* Float the button to the right */
        }
        .img-thumbnail {
            max-width: 200px; /* Limit the size of the displayed image */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Package</h2>
        </div>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="package_name" class="form-label">Package Name</label>
                <input type="text" class="form-control" id="package_name" name="package_name" value="<?php echo htmlspecialchars($package['package_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="package_des" class="form-label">Package Description</label>
                <textarea class="form-control" id="package_des" name="package_des" rows="3" required><?php echo htmlspecialchars($package['package_des']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="package_photo" class="form-label">Package Photo</label>
                <input type="file" class="form-control" id="package_photo" name="package_photo">
                <?php if (!empty($package['package_photo'])): ?>
                    <img src="<?php echo htmlspecialchars($package['package_photo']); ?>" alt="Current Photo" class="img-thumbnail mt-2">
                <?php endif; ?>
            </div>
            <a href="package.php" class="btn btn-secondary">Back to Package List</a>
            <button type="submit" class="btn btn-primary btn-right">Update Package</button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

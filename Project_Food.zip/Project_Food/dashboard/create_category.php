
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative;
        }
        h2 {
            color: #333;
        }
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 400px; /* Adjust width as needed */
            position: relative;
        }
        input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], .btn-menu, .btn-back {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
        input[type="submit"]:hover, .btn-menu:hover, .btn-back:hover {
            background-color: #218838;
        }
        .btn-menu {
            background-color: #007bff;
            width: 150px; /* Narrow width for the button */
            margin: 0; /* Remove margin */
        }
        .btn-menu:hover {
            background-color: #0056b3;
        }
        .btn-back {
            background-color: #6c757d;
            position: absolute;
            top: 20px;
            right: 2px;
            width: 100px; /* Narrow width for the button */
        }
        .btn-back:hover {
            background-color: #5a6268;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .error-message {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <a href="menu.php" class="btn-back">Back to Menu</a>
        <h2>Add Category</h2>
        <form action="" method="post">
            <label for="categoryName">Category Name:</label><br>
            <input type="text" id="categoryName" name="categoryName" required><br>
            <?php
            // Check if form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Include database connection
                include('connection.php');

                // Prepare and bind SQL statement for category insertion
                $sql_check = "SELECT category_id FROM category WHERE categoryName = ?";
                $stmt_check = $conn->prepare($sql_check);
                $stmt_check->bind_param("s", $categoryName);

                // Set parameters from POST data
                $categoryName = $_POST['categoryName'];

                // Execute SQL statement to check if category exists
                $stmt_check->execute();
                $stmt_check->store_result();

                // If category already exists, show warning
                if ($stmt_check->num_rows > 0) {
                    echo '<span class="error-message">Category name already exists. Please choose a different name.</span><br>';
                } else {
                    // Prepare and bind SQL statement for category insertion
                    $sql_insert = "INSERT INTO category (categoryName) VALUES (?)";
                    $stmt_insert = $conn->prepare($sql_insert);
                    $stmt_insert->bind_param("s", $categoryName);

                    // Execute SQL statement for category insertion
                    if ($stmt_insert->execute()) {
                        // Close statement
                        $stmt_insert->close();
                        // Close connection
                        $conn->close();
                        
                        // Redirect to create_menu.php upon successful insertion
                        header("Location: create_menu.php");
                        exit();
                    } else {
                        // Display error if insertion fails
                        echo '<span class="error-message">Error: ' . $sql_insert . '<br>' . $stmt_insert->error . '</span>';
                    }

                    // Close statement for insertion
                    $stmt_insert->close();
                }

                // Close statement for checking
                $stmt_check->close();
                // Close connection
                $conn->close();
            }
            ?>
            <br>
            <input type="submit" value="Add Category" style="width: 400px;">
        </form>
        <div class="btn-container">
            <a href="create_menu.php" class="btn-menu" style="width: 400px; text-align: center;">Direct To Menu</a>
        </div>
    </div>

    <!-- Required Library Bundle Script -->
    <script src="../assets/js/core/libs.min.js"></script>
    
    <!-- External Library Bundle Script -->
    <script src="../assets/js/core/external.min.js"></script>
    
    <!-- Mapchart JavaScript -->
    <script src="../assets/js/charts/dashboard.js"></script>
    
    <!-- fslightbox JavaScript -->
    <script src="../assets/js/fslightbox.js"></script>
    
    <!-- app JavaScript -->
    <script src="../assets/js/app.js"></script>
    
    <!-- moment JavaScript -->
    <script src="../assets/vendor/moment.min.js"></script>
</body>
</html>

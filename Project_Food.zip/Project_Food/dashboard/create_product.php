<?php
// Include database connection
include('connection.php');

// Initialize variables for error/success messages
$error_message = '';
$success_message = '';

// Create the product table if it doesn't exist
$table_check_sql = "SHOW TABLES LIKE 'product'";
$result = $conn->query($table_check_sql);

if ($result->num_rows == 0) {
    $create_table_sql = "
        CREATE TABLE product (
            product_id INT AUTO_INCREMENT PRIMARY KEY,
            product_name VARCHAR(255) NOT NULL,
            product_des TEXT,
            product_price DECIMAL(10, 2) NOT NULL,
            menu_id INT,
            category_id INT,
            FOREIGN KEY (menu_id) REFERENCES menu_item(menu_id),
            FOREIGN KEY (category_id) REFERENCES category(category_id)
        )";
    
    if ($conn->query($create_table_sql) === TRUE) {
        $success_message = "Product table created successfully.";
    } else {
        $error_message = "Error creating product table: " . $conn->error;
    }
} 

// Check and add the 'average_rating' column if it doesn't exist
$column_check_sql = "SHOW COLUMNS FROM product LIKE 'average_rating'";
$column_result = $conn->query($column_check_sql);

if ($column_result->num_rows == 0) {
    $alter_table_sql = "ALTER TABLE product ADD COLUMN average_rating DECIMAL(3, 2) DEFAULT NULL";
    
    if ($conn->query($alter_table_sql) === TRUE) {
        $success_message .= " Average rating column added successfully.";
    } else {
        $error_message .= " Error adding average rating column: " . $conn->error;
    }
}

// Create the product_photo table if it doesn't exist
$table_check_sql = "SHOW TABLES LIKE 'product_photo'";
$result = $conn->query($table_check_sql);

if ($result->num_rows == 0) {
    $create_table_sql = "
        CREATE TABLE product_photo (
            photo_id INT AUTO_INCREMENT PRIMARY KEY,
            photo_name VARCHAR(255) NOT NULL,
            photo_des TEXT,
            photo_path VARCHAR(255),
            product_id INT,
            FOREIGN KEY (product_id) REFERENCES product(product_id)
        )";
    
    if ($conn->query($create_table_sql) === TRUE) {
        $success_message .= " Product photo table created successfully.";
    } else {
        $error_message .= " Error creating product photo table: " . $conn->error;
    }
}

// Pre-populate menu_id and category_id from the query parameters
$menu_id = isset($_GET['menu_id']) ? htmlspecialchars($_GET['menu_id']) : '';
$category_id = isset($_GET['category_id']) ? htmlspecialchars($_GET['category_id']) : '';

// Fetch the menu name based on menu_id
$menu_name = '';
if ($menu_id) {
    $sql_menu_details = "SELECT menu_name FROM menu_item WHERE menu_id = ?";
    $stmt = $conn->prepare($sql_menu_details);
    $stmt->bind_param("i", $menu_id);
    $stmt->execute();
    $stmt->bind_result($menu_name);
    $stmt->fetch();
    $stmt->close();

    if (empty($menu_name)) {
        $error_message = "Menu Name not found for menu ID: $menu_id";
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $product_name = htmlspecialchars($_POST['product_name']);
    $product_des = htmlspecialchars($_POST['product_des']);
    $product_price = htmlspecialchars($_POST['product_price']);
    $menu_id = htmlspecialchars($_POST['menu_id']);
    $category_id = htmlspecialchars($_POST['category_id']);
    
    // Handle file upload
    $upload_dir = '../dashboard/product_img/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $photo_name = $_FILES['photo_name']['name'];
    $photo_tmp_name = $_FILES['photo_name']['tmp_name'];
    $photo_path = $upload_dir . basename($photo_name);
    $photo_des = htmlspecialchars($_POST['photo_des']);

    if ($_FILES['photo_name']['error'] === UPLOAD_ERR_OK) {
        if (move_uploaded_file($photo_tmp_name, $photo_path)) {
            // Insert data into the product table
            $sql = "INSERT INTO product (product_name, product_des, product_price, menu_id, category_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssdis", $product_name, $product_des, $product_price, $menu_id, $category_id);

            if ($stmt->execute()) {
                $product_id = $stmt->insert_id;

                // Insert data into the product_photo table
                $sql_photo = "INSERT INTO product_photo (photo_name, photo_des, photo_path, product_id) VALUES (?, ?, ?, ?)";
                $stmt_photo = $conn->prepare($sql_photo);
                $stmt_photo->bind_param("sssi", $photo_name, $photo_des, $photo_path, $product_id);
                
                if ($stmt_photo->execute()) {
                    // Redirect to product.php with both menu_id and category_id as query parameters
                    header("Location: product.php?menu_id=" . urlencode($menu_id) . "&category_id=" . urlencode($category_id));
                    exit();
                } else {
                    $error_message = "Error inserting photo data: " . $stmt_photo->error;
                }

                $stmt_photo->close();
            } else {
                $error_message = "Error inserting product data: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $error_message = "Error uploading file.";
        }
    } else {
        $error_message = 'File upload error: ' . $_FILES['photo_name']['error'];
    }
    
    $conn->close();
}
?>

<!doctype html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Aprycot | Restaurant Management Admin Template</title>

  <!-- Favicon -->
  <link rel="shortcut icon" href="../assets/images/favicon.ico" />

  <!-- Library / Plugin Css Build -->
  <link rel="stylesheet" href="../assets/css/core/libs.min.css">

  <!-- Custom Css -->
  <link rel="stylesheet" href="../assets/css/aprycot.min.css?v=1.0.0">
</head>

<style>
  .carousel-inner {
    overflow: hidden;
  }

  .fixed-form-container {
    max-width: 600px; /* Adjust the width as needed */
    margin: 0 auto; /* Center the form */
    padding: 20px; /* Add padding for better spacing */
  }
  
  .ae {
    margin-left: 200px;
  } 

  .i{
    float:right;
  }
</style>

<body style="background:url(../assets/images/dashboard.png); background-attachment: fixed; background-size: cover;">
  <div class="container mt-5">
    <div class="fixed-form-container bg-light">
      <h1 class="mb-4">Create Product</h1>
      <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
      <?php endif; ?>
      <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>
      <form method="POST" action="create_product.php" enctype="multipart/form-data">
        <div class="form-group">
          <label for="product_name">Product Name</label>
          <input type="text" class="form-control" id="product_name" name="product_name" required>
        </div>
        <div class="form-group">
          <label for="product_des">Product Description</label>
          <input type="text" class="form-control" id="product_des" name="product_des" required>
        </div>
        <div class="form-group">
          <label for="product_price">Product Price</label>
          <input type="number" step="0.01" class="form-control" id="product_price" name="product_price" required>
        </div>
        
        <div class="form-group">
          <label for="menu_name">Menu Name</label>
          <input type="text" class="form-control" id="menu_name" name="menu_name" value="<?php echo htmlspecialchars($menu_name); ?>" readonly required>
          <input type="hidden" name="menu_id" value="<?php echo htmlspecialchars($menu_id); ?>">
          <input type="hidden" name="category_id" value="<?php echo htmlspecialchars($category_id); ?>">
        </div>
        <div class="form-group">
          <label for="photo_name">Product Image</label>
          <input type="file" class="form-control" id="photo_name" name="photo_name" accept="image/*" required>
        </div>
        <div class="form-group">
          <label for="photo_des">Product Image Description</label>
          <input type="text" class="form-control" id="photo_des" name="photo_des" required>
        </div>
        <a href="menu.php" class="btn btn-primary">Back To Menu</a>
        <button type="submit" class="btn btn-primary" style="margin-left: 200px;">Create Product</button>
      </form>
    </div>
  </div>

  <!-- Library / Plugin Js -->
  <script src="../assets/js/core/libs.min.js"></script>

  <!-- Main Js -->
  <script src="../assets/js/core/aprycot.min.js?v=1.0.0"></script>
</body>
</html>

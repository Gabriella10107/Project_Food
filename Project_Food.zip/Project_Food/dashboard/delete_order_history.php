<?php
// Include database connection
include('connection.php');

// Check if the order_id parameter is set in the query string
if (isset($_GET['order_id'])) {
    // Get the order_id from the query string and decode it
    $order_id = urldecode($_GET['order_id']);

    // Prepare the SQL DELETE statement
    $sql_delete = "DELETE FROM order_customer WHERE order_id = ?";
    $stmt = $conn->prepare($sql_delete);

    // Check if the statement preparation was successful
    if ($stmt !== false) {
        // Bind the order_id parameter to the statement
        $stmt->bind_param('i', $order_id);

        // Execute the statement
        $stmt->execute();

        // Close the statement
        $stmt->close();
    }

    // Redirect to the order history page after deletion
    header("Location: order_history.php");
    exit();
}

// Close the database connection
$conn->close();
?>

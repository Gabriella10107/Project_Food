<?php
// Include database connection
include('connection.php');

// Check if menu_id and category_id are provided via GET request
if (isset($_GET['menu_id']) && isset($_GET['category_id'])) {
    $menu_id = $_GET['menu_id'];
    $category_id = $_GET['category_id'];

    // Validate menu_id and category_id are integers
    if (filter_var($menu_id, FILTER_VALIDATE_INT) && filter_var($category_id, FILTER_VALIDATE_INT)) {
        // Start a transaction
        $conn->begin_transaction();

        try {
            // First, get the image filename associated with the menu item
            $sql_get_image = "SELECT menu_photo FROM menu_item WHERE menu_id = ?";
            $stmt_get_image = $conn->prepare($sql_get_image);
            $stmt_get_image->bind_param("i", $menu_id);
            $stmt_get_image->execute();
            $stmt_get_image->bind_result($menu_photo);
            $stmt_get_image->fetch();
            $stmt_get_image->close();

            // Delete dependent records from the product_photo table
            $sql_delete_product_photo = "DELETE FROM product_photo WHERE product_id IN (SELECT product_id FROM product WHERE menu_id = ?)";
            $stmt_delete_product_photo = $conn->prepare($sql_delete_product_photo);
            $stmt_delete_product_photo->bind_param("i", $menu_id);
            $stmt_delete_product_photo->execute();
            $stmt_delete_product_photo->close();

            // Then, delete dependent records from the product table
            $sql_delete_product = "DELETE FROM product WHERE menu_id = ?";
            $stmt_delete_product = $conn->prepare($sql_delete_product);
            $stmt_delete_product->bind_param("i", $menu_id);
            $stmt_delete_product->execute();
            $stmt_delete_product->close();

            // Finally, delete the menu item
            $sql_delete_menu = "DELETE FROM menu_item WHERE menu_id = ? AND category_id = ?";
            $stmt_delete_menu = $conn->prepare($sql_delete_menu);
            $stmt_delete_menu->bind_param("ii", $menu_id, $category_id);
            $stmt_delete_menu->execute();
            $stmt_delete_menu->close();

            // Commit the transaction
            $conn->commit();

            // Delete the associated image file if it exists
            if ($menu_photo) {
                $file_path = 'upload_menu_item/' . $menu_photo;
                if (file_exists($file_path)) {
                    unlink($file_path); // Delete the file
                }
            }

            // Redirect to menu.php after successful deletion
            header("Location: menu.php");
            exit();
        } catch (mysqli_sql_exception $exception) {
            // Rollback the transaction if an error occurs
            $conn->rollback();
            echo "Error deleting menu item: " . htmlspecialchars($exception->getMessage());
        }
    } else {
        echo "Invalid menu_id or category_id.";
    }
} else {
    // Redirect if menu_id or category_id is not provided
    header("Location: menu.php"); // Redirect to menu page
    exit();
}

// Close the database connection
$conn->close();

// Function to check if a directory is empty
function is_dir_empty($dir) {
    return is_dir($dir) && count(scandir($dir)) == 2;
}
?>

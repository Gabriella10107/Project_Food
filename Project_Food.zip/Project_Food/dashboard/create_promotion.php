<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
include('connection.php');

// Create the promotion table if it doesn't exist
$sql_promotion = "CREATE TABLE IF NOT EXISTS promotion (
    promotion_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    promotion_percent DECIMAL(5,2) NOT NULL,
    product_id INT(6) NOT NULL,
    menu_id INT(6) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES product(product_id),
    FOREIGN KEY (menu_id) REFERENCES menu_item(menu_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute the SQL query to create the promotion table
if ($conn->query($sql_promotion) !== TRUE) {
    die("Error creating promotion table: " . $conn->error);
}

// Initialize messages and variables
$success_message = '';
$error_message = '';

// Retrieve package_id from URL query parameter
$package_id = isset($_GET['package_id']) ? intval($_GET['package_id']) : 0;

// Handle AJAX requests for product options
if (isset($_GET['menu_id'])) {
    $selected_menu_id = intval($_GET['menu_id']);
    $stmt = $conn->prepare("
        SELECT p.product_id, p.product_name 
        FROM product p
        WHERE p.menu_id = ?
    ");
    $stmt->bind_param("i", $selected_menu_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $stmt->close();
    echo json_encode($products);
    exit;
}

// Handle AJAX requests for package details
if (isset($_GET['product_id'])) {
    $selected_product_id = intval($_GET['product_id']);
    $stmt = $conn->prepare("
        SELECT menu_id 
        FROM product 
        WHERE product_id = ?
    ");
    $stmt->bind_param("i", $selected_product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $menu_id = $row['menu_id'];
    }
    $stmt->close();
    echo json_encode(['menu_id' => $menu_id, 'package_id' => $package_id]);
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $menu_id = intval($_POST['menu_id']);
    $product_id = intval($_POST['product_id']);
    $promotion_percent = floatval($_POST['promotion_percent']);

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO promotion (promotion_percent, product_id, menu_id) VALUES (?, ?, ?)");
    $stmt->bind_param("dii", $promotion_percent, $product_id, $menu_id);

    if ($stmt->execute()) {
        $success_message = "Promotion added successfully!";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch menu items
$menus = $conn->query("SELECT menu_id, menu_name FROM menu_item");

// Fetch products
$products = $conn->query("SELECT product_id, product_name FROM product");

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Promotion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f8f9fa;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .btn-right {
            float: right;
        }
        .info-box {
            margin-top: 20px;
        }
        .loading-spinner {
            display: none;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <h2 class="text-center mb-4">Add Promotion</h2>
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <form action="" method="post">
            <div class="mb-3">
                <label for="menu_id" class="form-label">Menu Item</label>
                <select class="form-select" id="menu_id" name="menu_id" required>
                    <option value="" disabled selected>Select a menu item</option>
                    <?php while ($menu = $menus->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($menu['menu_id']); ?>">
                            <?php echo htmlspecialchars($menu['menu_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="product_id" class="form-label">Product</label>
                <select class="form-select" id="product_id" name="product_id" required>
                    <option value="" disabled selected>Select a product</option>
                    <!-- Options will be dynamically added here -->
                </select>
                <div id="loading-spinner" class="loading-spinner text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="promotion_percent" class="form-label">Promotion Percent</label>
                <input type="number" class="form-control" id="promotion_percent" name="promotion_percent" step="0.01" min="0" max="100" required>
            </div>
            <div class="d-flex justify-content-between">
                <a href="promotion.php" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary btn-right">Add Promotion</button>
            </div>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('menu_id').addEventListener('change', function() {
        var menuId = this.value;
        var productSelect = document.getElementById('product_id');
        var loadingSpinner = document.getElementById('loading-spinner');

        // Clear previous options
        productSelect.innerHTML = '<option value="" disabled selected>Select a product</option>';

        if (menuId) {
            // Show loading spinner
            loadingSpinner.style.display = 'block';

            // Fetch products based on the selected menu_id
            fetch('?menu_id=' + menuId)
                .then(response => response.json())
                .then(data => {
                    // Hide loading spinner
                    loadingSpinner.style.display = 'none';

                    // Check if data is an array
                    if (Array.isArray(data)) {
                        // Add options to the product select element
                        data.forEach(product => {
                            var option = document.createElement('option');
                            option.value = product.product_id;
                            option.text = product.product_name;
                            productSelect.add(option);
                        });
                    } else {
                        console.error('Expected array but received:', data);
                    }
                })
                .catch(error => {
                    // Hide loading spinner
                    loadingSpinner.style.display = 'none';
                    console.error('Error fetching products:', error);
                });
        }
    });
</script>
</body>
</html>

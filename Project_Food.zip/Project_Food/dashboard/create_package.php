<?php
// Include the database connection file
include('connection.php');

// SQL to create menu_item table if it doesn't exist
$sql_menu = "CREATE TABLE IF NOT EXISTS menu_item (
    menu_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    menu_name VARCHAR(255) NOT NULL
)";
if (!$conn->query($sql_menu)) {
    die("Error creating menu_item table: " . $conn->error);
}

// SQL to create package table if it doesn't exist
$sql_package = "CREATE TABLE IF NOT EXISTS package (
    package_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(255) NOT NULL,
    package_des TEXT NOT NULL,
    package_photo VARCHAR(255) NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
if (!$conn->query($sql_package)) {
    die("Error creating package table: " . $conn->error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $package_name = $_POST['package_name'];
    $package_des = $_POST['package_des'];

    // File upload validation
    $target_dir = "../dashboard/upload_package/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $target_file = $target_dir . basename($_FILES["package_photo"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validate file size (e.g., 5MB max)
    if ($_FILES["package_photo"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        exit();
    }

    // Validate file type
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        exit();
    }

    if (move_uploaded_file($_FILES["package_photo"]["tmp_name"], $target_file)) {
        $package_photo = $target_file;

        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO package (package_name, package_des, package_photo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $package_name, $package_des, $package_photo);

        if ($stmt->execute()) {
            // Redirect to package.php after successful insert
            header("Location: package.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        
        $stmt->close();
    } else {
        echo "Error uploading file.";
    }

    // Close the database connection
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Package</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px; /* Adjust the max width as needed */
            margin: 0 auto;   /* Center the form horizontally */
        }
        .btn-right {
            float: right; /* Float the button to the right */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Add New Package</h2>
        </div>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="package_name" class="form-label">Package Name</label>
                <input type="text" class="form-control" id="package_name" name="package_name" required>
            </div>
            <div class="mb-3">
                <label for="package_des" class="form-label">Package Description</label>
                <textarea class="form-control" id="package_des" name="package_des" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="package_photo" class="form-label">Package Photo</label>
                <input type="file" class="form-control" id="package_photo" name="package_photo" required>
            </div>

            <a href="package.php" class="btn btn-secondary">Back to Package List</a>
            <button type="submit" class="btn btn-primary btn-right">Add Package</button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

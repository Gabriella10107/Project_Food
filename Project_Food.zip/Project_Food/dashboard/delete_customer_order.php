<?php
// Include database connection
include('connection.php');

// Get customer email from query parameter, if available
$customer_email = isset($_GET['customer_email']) ? htmlspecialchars($_GET['customer_email']) : '';

if ($customer_email === '') {
    die('No customer email specified.');
}

// Start transaction
$conn->begin_transaction();

try {
    // Prepare and execute the deletion of related records
    // Delete from customer_product table
    $sql_delete_customer_product = "DELETE cp FROM customer_product cp
                                    JOIN order_customer oc ON cp.order_id = oc.order_id
                                    JOIN customer c ON oc.customer_id = c.customer_id
                                    WHERE c.customer_email = ?";
    $stmt = $conn->prepare($sql_delete_customer_product);
    if ($stmt === false) {
        throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('s', $customer_email);
    if (!$stmt->execute()) {
        throw new Exception('Execute failed: ' . htmlspecialchars($stmt->error));
    }
    $stmt->close();

    // Delete from order_customer table
    $sql_delete_order_customer = "DELETE oc FROM order_customer oc
                                  JOIN customer c ON oc.customer_id = c.customer_id
                                  WHERE c.customer_email = ?";
    $stmt = $conn->prepare($sql_delete_order_customer);
    if ($stmt === false) {
        throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('s', $customer_email);
    if (!$stmt->execute()) {
        throw new Exception('Execute failed: ' . htmlspecialchars($stmt->error));
    }
    $stmt->close();

    // Delete from customer table
    $sql_delete_customer = "DELETE FROM customer WHERE customer_email = ?";
    $stmt = $conn->prepare($sql_delete_customer);
    if ($stmt === false) {
        throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('s', $customer_email);
    if (!$stmt->execute()) {
        throw new Exception('Execute failed: ' . htmlspecialchars($stmt->error));
    }
    $stmt->close();

    // Commit transaction
    $conn->commit();

    // Redirect or display a success message
    echo "<script>alert('Customer and related orders deleted successfully.'); window.location.href = 'order.php';</script>";

} catch (Exception $e) {
    // Rollback transaction in case of error
    $conn->rollback();
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'your_previous_page.php';</script>";
}

// Close connection
$conn->close();
?>

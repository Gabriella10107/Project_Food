<?php
// Include database connection
include('connection.php');

// Function to update order status and customer product status
function updateStatuses($conn, $order_id) {
    // Ensure order_id is valid
    if ($order_id <= 0) {
        return false;  // Return false to indicate an invalid order ID
    }

    // Get the current time in Asia/Yangon time zone
    date_default_timezone_set('Asia/Yangon');
    $current_time = date('Y-m-d H:i:s');

    // Update the order status to inactive and set end_date
    $sql_update_order = "UPDATE order_customer 
                         SET active = 0, end_date = ? 
                         WHERE order_id = ? AND active = 1";
    $stmt = $conn->prepare($sql_update_order);
    if ($stmt === false) {
        return false;  // Return false to indicate a prepare statement failure
    }
    $stmt->bind_param('si', $current_time, $order_id);
    if (!$stmt->execute()) {
        return false;  // Return false to indicate an execute statement failure
    }

    // Check if any rows were affected
    if ($stmt->affected_rows === 0) {
        // Do nothing if no rows were updated
    }

    // Update the customer product status to inactive
    $sql_update_customer_product = "UPDATE customer_product 
                                    SET active_product = 0 
                                    WHERE order_id = ? AND active_product = 1";
    $stmt_product = $conn->prepare($sql_update_customer_product);
    if ($stmt_product === false) {
        return false;  // Return false to indicate a prepare statement failure
    }
    $stmt_product->bind_param('i', $order_id);
    if (!$stmt_product->execute()) {
        return false;  // Return false to indicate an execute statement failure
    }

    // Check if any rows were affected
    if ($stmt_product->affected_rows === 0) {
        // Do nothing if no rows were updated
    }

    // Close statements
    $stmt->close();
    $stmt_product->close();

    return true;  // Return true to indicate success
}

// Get the order_id from the query string
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

// Update the statuses
$update_successful = updateStatuses($conn, $order_id);

// Redirect to the order page
header('Location: order.php');
exit();

// Close connection
$conn->close();
?>

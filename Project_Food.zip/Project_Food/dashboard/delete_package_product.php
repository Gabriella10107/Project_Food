<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
include('connection.php');

// SQL to create the package_product table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS package_product (
    package_product_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    menu_item_id INT(6) UNSIGNED NOT NULL,
    product_id INT(6) UNSIGNED NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute the SQL query to create the table
if ($conn->query($sql) !== TRUE) {
    die("Error creating table: " . $conn->error);
}

// Initialize messages and variables
$success_message = '';
$error_message = '';
$menu_id = null;
$edit_id = null;

// Handle form submission for adding or editing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $menu_item_id = intval($_POST['menu_item_id']);
    $product_id = intval($_POST['product_id']);
    $status = $_POST['status'];
    $edit_id = isset($_POST['edit_id']) ? intval($_POST['edit_id']) : null;

    if ($edit_id) {
        // Update existing record
        $stmt = $conn->prepare("UPDATE package_product SET menu_item_id = ?, product_id = ?, status = ? WHERE package_product_id = ?");
        $stmt->bind_param("iisi", $menu_item_id, $product_id, $status, $edit_id);
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO package_product (menu_item_id, product_id, status) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $menu_item_id, $product_id, $status);
    }

    if ($stmt->execute()) {
        $success_message = $edit_id ? "Product updated successfully!" : "Product added successfully!";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Handle record deletion
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM package_product WHERE package_product_id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $success_message = "Product deleted successfully!";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch menu items
$menus = $conn->query("SELECT menu_id, menu_name FROM menu_item");

// Fetch existing record if edit ID is provided
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT * FROM package_product WHERE package_product_id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $edit_record = $result->fetch_assoc();
    $stmt->close();
}

// Fetch all package_product records for display
$records = $conn->query("SELECT pp.package_product_id, mi.menu_name, p.product_name, pp.status
                         FROM package_product pp
                         JOIN menu_item mi ON pp.menu_item_id = mi.menu_id
                         JOIN product p ON pp.product_id = p.product_id");

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $edit_id ? 'Edit Menu Product' : 'Add Menu Product'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 0 auto;
        }
        .btn-right {
            float: right;
        }
        .info-box {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <h2><?php echo $edit_id ? 'Edit Menu Product' : 'Add Menu Product'; ?></h2>
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <form action="" method="post">
            <input type="hidden" name="edit_id" value="<?php echo htmlspecialchars($edit_id); ?>">
            <div class="mb-3">
                <label for="menu_item_id" class="form-label">Menu Item</label>
                <select class="form-select" id="menu_item_id" name="menu_item_id" required>
                    <option value="" disabled selected>Select a menu item</option>
                    <?php while ($menu = $menus->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($menu['menu_id']); ?>" <?php echo isset($edit_record) && $edit_record['menu_item_id'] == $menu['menu_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($menu['menu_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="product_id" class="form-label">Product</label>
                <select class="form-select" id="product_id" name="product_id" required>
                    <option value="" disabled selected>Select a product</option>
                    <!-- Options will be dynamically added here -->
                </select>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="active" <?php echo isset($edit_record) && $edit_record['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo isset($edit_record) && $edit_record['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <a href="menu.php" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary btn-right"><?php echo $edit_id ? 'Update Menu Product' : 'Add Menu Product'; ?></button>
        </form>

        <!-- Display existing records with delete options -->
        <h3 class="mt-5">Existing Menu Products</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Menu Item</th>
                    <th>Product</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $records->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['menu_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="?edit_id=<?php echo htmlspecialchars($row['package_product_id']); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="?delete_id=<?php echo htmlspecialchars($row['package_product_id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Display related menu ID if available -->
        <div class="info-box">
            <h4>Selected Product's Related Menu ID:</h4>
            <p id="related-menu-id">N/A</p>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('menu_item_id').addEventListener('change', function() {
        var menuItemId = this.value;
        var productSelect = document.getElementById('product_id');

        // Clear previous options
        productSelect.innerHTML = '<option value="" disabled selected>Select a product</option>';

        if (menuItemId) {
            // Fetch products based on the selected menu_item_id
            fetch('?menu_item_id=' + menuItemId)
                .then(response => response.json())
                .then(data => {
                    // Check if data is an array
                    if (Array.isArray(data)) {
                        data.forEach(product => {
                            var option = document.createElement('option');
                            option.value = product.product_id;
                            option.text = product.product_name;
                            productSelect.add(option);
                        });
                    }
                });
        }
    });
</script>
</body>
</html>

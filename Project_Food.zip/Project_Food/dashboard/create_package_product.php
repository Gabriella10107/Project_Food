<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
include('connection.php');

// Create the package_product table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS package_product (
    package_product_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    menu_id INT(6) NOT NULL,
    product_id INT(6) NOT NULL,
    package_id INT(6) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (menu_id) REFERENCES menu_item(menu_id),
    FOREIGN KEY (product_id) REFERENCES product(product_id),
    FOREIGN KEY (package_id) REFERENCES package(package_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute the SQL query to create the table
if ($conn->query($sql) !== TRUE) {
    die("Error creating table: " . $conn->error);
}

// Initialize messages and variables
$success_message = '';
$error_message = '';

// Retrieve package_id from URL query parameter
$package_id = isset($_GET['package_id']) ? intval($_GET['package_id']) : 0;

// Handle AJAX requests for product options
if (isset($_GET['menu_id'])) {
    $selected_menu_id = intval($_GET['menu_id']);
    $stmt = $conn->prepare("
        SELECT p.product_id, p.product_name 
        FROM product p
        WHERE p.menu_id = ?
    ");
    $stmt->bind_param("i", $selected_menu_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $stmt->close();
    echo json_encode($products);
    exit;
}

// Handle AJAX requests for package details
if (isset($_GET['product_id'])) {
    $selected_product_id = intval($_GET['product_id']);
    $stmt = $conn->prepare("
        SELECT menu_id 
        FROM product 
        WHERE product_id = ?
    ");
    $stmt->bind_param("i", $selected_product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $menu_id = $row['menu_id'];
    }
    $stmt->close();
    echo json_encode(['menu_id' => $menu_id, 'package_id' => $package_id]);
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $menu_id = intval($_POST['menu_id']);
    $product_id = intval($_POST['product_id']);
    $status = $_POST['status'];

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO package_product (menu_id, product_id, package_id, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $menu_id, $product_id, $package_id, $status);

    if ($stmt->execute()) {
        $success_message = "Product added successfully!";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch menu items and packages
$menus = $conn->query("SELECT menu_id, menu_name FROM menu_item");
$packages = $conn->query("SELECT package_id, package_name FROM package");

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Menu Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 0 auto;
        }
        .btn-right {
            float: right;
        }
        .info-box {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <h2>Add Menu Product</h2>
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <form action="" method="post">
            <div class="mb-3">
                <label for="menu_id" class="form-label">Menu Item</label>
                <select class="form-select" id="menu_id" name="menu_id" required>
                    <option value="" disabled selected>Select a menu item</option>
                    <?php while ($menu = $menus->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($menu['menu_id']); ?>">
                            <?php echo htmlspecialchars($menu['menu_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="product_id" class="form-label">Product</label>
                <select class="form-select" id="product_id" name="product_id" required>
                    <option value="" disabled selected>Select a product</option>
                    <!-- Options will be dynamically added here -->
                </select>
            </div>
            <input type="hidden" id="package_id" name="package_id" value="<?php echo htmlspecialchars($package_id); ?>">
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <a href="package.php" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary btn-right">Add Menu Product</button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('menu_id').addEventListener('change', function() {
        var menuId = this.value;
        var productSelect = document.getElementById('product_id');

        // Clear previous options
        productSelect.innerHTML = '<option value="" disabled selected>Select a product</option>';

        if (menuId) {
            // Fetch products based on the selected menu_id
            fetch('?menu_id=' + menuId)
                .then(response => response.json())
                .then(data => {
                    // Check if data is an array
                    if (Array.isArray(data)) {
                        // Add options to the product select element
                        data.forEach(product => {
                            var option = document.createElement('option');
                            option.value = product.product_id;
                            option.text = product.product_name;
                            productSelect.add(option);
                        });
                    } else {
                        console.error('Expected array but received:', data);
                    }
                })
                .catch(error => console.error('Error fetching products:', error));
        }
    });

    document.getElementById('product_id').addEventListener('change', function() {
        var productId = this.value;
        var packageInput = document.getElementById('package_id');

        if (productId) {
            // Fetch related package ID based on the selected product_id
            fetch('?product_id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        packageInput.value = data.package_id;
                    }
                })
                .catch(error => console.error('Error fetching package ID:', error));
        }
    });
</script>
</body>
</html>

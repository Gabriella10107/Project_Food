<?php
include('connection.php');

// Get the product_id from the request
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

// Fetch related images from the database
$sql = "SELECT pp.photo_path 
        FROM product_photo pp
        WHERE pp.product_id = $product_id";
$result = $conn->query($sql);

// Display the images
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="product-image">';
        echo '  <img src="' . htmlspecialchars($row['photo_path']) . '" alt="Product Image" class="img-fluid">';
        echo '</div>';
    }
} else {
    echo '<p>No images found for this product.</p>';
}

$conn->close();
?>

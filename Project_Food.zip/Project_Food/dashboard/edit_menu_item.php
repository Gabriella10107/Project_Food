<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .btn-full-width {
            width: 100%;
            padding: 10px 0;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
        }
        img {
            border-radius: 5px;
            margin-top: 10px;
        }
        .form-label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Edit Menu Item</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        // Database connection
                        include("connection.php");

                        // Initialize variables for storing existing data
                        $menu_name = '';
                        $menu_des = '';
                        $menu_photo = '';
                        $menu_status = 'active'; // Default status
                        $category_id = 0; // Default category ID

                        // Check if ID is provided via GET method
                        if (isset($_GET['menu_id'])) {
                            $id = $_GET['menu_id'];

                            // Retrieve existing menu item data from database
                            $sql = "SELECT * FROM menu_item WHERE menu_id = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("i", $id);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $menu_name = $row['menu_name'];
                                $menu_des = $row['menu_des'];
                                $menu_photo = $row['menu_photo'];
                                $menu_status = $row['menu_status'];
                                $category_id = $row['category_id'];
                            } else {
                                echo '<div class="alert alert-danger">Menu item not found.</div>';
                                exit(); // Exit if menu item ID not found
                            }
                        } else {
                            echo '<div class="alert alert-danger">Menu item ID not provided.</div>';
                            exit(); // Exit if menu item ID is not provided
                        }

                        // Handle form submission for updating menu item
                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                            // Get updated form data
                            $menu_name = $_POST['menu_name'];
                            $menu_des = $_POST['menu_des'];
                            $menu_status = $_POST['menu_status'];
                            $category_id = $_POST['category_id'];

                            // Check if a new photo is uploaded
                            if ($_FILES['menu_photo']['size'] > 0) {
                                // Delete the old image if it exists
                                if (!empty($menu_photo)) {
                                    $old_file_path = 'upload_menu_item/' . $menu_photo;
                                    if (file_exists($old_file_path)) {
                                        unlink($old_file_path); // Delete the old file
                                    }
                                }

                                // Upload new image
                                $menu_photo = basename($_FILES['menu_photo']['name']);
                                $menu_photo_path = 'upload_menu_item/' . $menu_photo;
                                $menu_photo_tmp = $_FILES['menu_photo']['tmp_name'];
                                move_uploaded_file($menu_photo_tmp, $menu_photo_path);
                            }

                            // Update data in the database
                            $sql = "UPDATE menu_item SET menu_name = ?, menu_des = ?, menu_photo = ?, menu_status = ?, category_id = ? WHERE menu_id = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("ssssii", $menu_name, $menu_des, $menu_photo, $menu_status, $category_id, $id);

                            if ($stmt->execute()) {
                                header('Location: menu.php'); // Redirect after successful update
                                exit();
                            } else {
                                echo '<div class="alert alert-danger">Error updating menu item: ' . $stmt->error . '</div>';
                            }
                        }
                        ?>
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="menu_name" class="form-label">Menu Name</label>
                                <input type="text" class="form-control" id="menu_name" name="menu_name" value="<?php echo htmlspecialchars($menu_name); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="menu_des" class="form-label">Description</label>
                                <textarea class="form-control" id="menu_des" name="menu_des" rows="3"><?php echo htmlspecialchars($menu_des); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="menu_photo" class="form-label">Photo</label>
                                <input type="file" class="form-control" id="menu_photo" name="menu_photo" accept="image/*">
                                <?php if (!empty($menu_photo)): ?>
                                    <div class="text-center">
                                        <img src="<?php echo 'upload_menu_item/' . htmlspecialchars($menu_photo); ?>" alt="Menu Image" style="width: 100px; height: auto;">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="menu_status" class="form-label">Status</label>
                                <select class="form-control" id="menu_status" name="menu_status">
                                    <option value="active" <?php if ($menu_status == 'active') echo 'selected'; ?>>Active</option>
                                    <option value="inactive" <?php if ($menu_status == 'inactive') echo 'selected'; ?>>Inactive</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="category_id" class="form-label">Category</label>
                                <select class="form-control" id="category_id" name="category_id">
                                    <?php
                                    // Fetch categories from the 'category' table
                                    $sql = "SELECT category_id, categoryName FROM category";
                                    $result = $conn->query($sql);

                                    // Display categories as options in the dropdown
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $selected = ($row['category_id'] == $category_id) ? 'selected' : '';
                                            echo '<option value="' . $row['category_id'] . '" ' . $selected . '>' . htmlspecialchars($row['categoryName']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-full-width">Update Menu Item</button>
                            </div>
                            <div class="text-center">
                                <a href="menu.php" class="btn btn-primary btn-full-width mt-3">Back To Menu</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

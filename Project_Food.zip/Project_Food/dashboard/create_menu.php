<?php
// Include database connection
include('connection.php');

// Ensure the upload directory exists
$upload_dir = 'upload_menu_item/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true); // create directory if it doesn't exist
}

// SQL to create menu_item table if it doesn't exist
$sql_create_table = "
CREATE TABLE IF NOT EXISTS menu_item (
    menu_id INT AUTO_INCREMENT PRIMARY KEY,
    menu_name VARCHAR(255) NOT NULL,
    menu_des TEXT,
    menu_photo VARCHAR(255),
    menu_status ENUM('active', 'inactive') DEFAULT 'active',
    category_id INT,
    CONSTRAINT fk_category
        FOREIGN KEY (category_id)
        REFERENCES category(category_id)
        ON DELETE CASCADE
)";

// Execute query to create table
if ($conn->query($sql_create_table) === TRUE) {
    echo "<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Menu Item</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], textarea, input[type="file"], select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
        }
        textarea {
            resize: vertical;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .btn-menu {
            width: 480px;
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin-top: 3px;
        }
        .btn-menu:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Menu Item</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="menu_name">Menu Name:</label>
            <input type="text" id="menu_name" name="menu_name" required>
            
            <label for="menu_des">Description:</label>
            <textarea id="menu_des" name="menu_des"></textarea>
            
            <label for="menu_photo">Photo:</label>
            <input type="file" id="menu_photo" name="menu_photo">
            
            <label for="menu_status">Status:</label>
            <select id="menu_status" name="menu_status">
                <option value="active" selected>Active</option>
                <option value="inactive">Inactive</option>
            </select>
            
            <label for="category_id">Category:</label>
            <select id="category_id" name="category_id">
                <?php
                // Include database connection
                include('connection.php');

                // Fetch categories from the 'category' table
                $sql = "SELECT category_id, categoryName FROM category";
                $result = $conn->query($sql);

                // Display categories as options in the dropdown
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['category_id'] . '">' . $row['categoryName'] . '</option>';
                    }
                }

                // Close database connection
                $conn->close();
                ?>
            </select>
            
            <input type="submit" value="Add Menu Item">
        </form>
        <a href="create_category.php" class="btn-menu" >Back</a>
    </div>
</body>
</html>
<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    include('connection.php');

    // Prepare and bind SQL statement for menu item insertion
    $sql = "INSERT INTO menu_item (menu_name, menu_des, menu_photo, menu_status, category_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $menu_name, $menu_des, $menu_photo, $menu_status, $category_id);

    // Set parameters from POST data
    $menu_name = $_POST['menu_name'];
    $menu_des = $_POST['menu_des'];
    $menu_status = $_POST['menu_status'];
    $category_id = $_POST['category_id'];

    // Upload photo handling
    $menu_photo = '';
    if ($_FILES['menu_photo']['error'] == UPLOAD_ERR_OK) {
        $menu_photo = $_FILES['menu_photo']['name'];
        move_uploaded_file($_FILES['menu_photo']['tmp_name'], $upload_dir . $menu_photo);
    }

    // Execute SQL statement for menu item insertion
    if ($stmt->execute()) {
        // Close statement
        $stmt->close();
        // Close connection
        $conn->close();
        
        // Redirect to success page upon successful insertion
        header("Location: create_menu_success.html");
        exit();
    } else {
        // Display error if insertion fails
        echo "Error: " . $sql . "<br>" . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
